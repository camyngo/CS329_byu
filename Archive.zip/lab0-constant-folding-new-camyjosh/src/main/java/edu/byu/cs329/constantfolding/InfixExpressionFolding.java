package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.NumberLiteral;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// left and right
public class InfixExpressionFolding implements Folding {
  static final Logger log = LoggerFactory.getLogger(InfixExpressionFolding.class);

  static class Visitor extends ASTVisitor {
    public boolean didFold = false;

    private boolean isLiteralExpression(ASTNode exp) {
      return exp instanceof NumberLiteral;
    }

    @Override
    public void endVisit(InfixExpression node) {
      if (node == null) {
        return;
      }
      if (node.getOperator() == InfixExpression.Operator.PLUS) {
        ASTNode exp = node.getRoot();
        // checking if left and right is an instance if number literals
        if (isLiteralExpression(node.getLeftOperand())
                && isLiteralExpression(node.getRightOperand())) {
          NumberLiteral x = (NumberLiteral) node.getRightOperand();
          int right = Integer.parseInt(x.getToken());
          NumberLiteral x2 = (NumberLiteral) node.getLeftOperand();
          int left = Integer.parseInt(x2.getToken());
          int total = left + right;
          AST ast = node.getAST();
          // turn total into a string
          String tree = String.valueOf(total);
          NumberLiteral ast2 = ast.newNumberLiteral(tree);

          // make a new AST Node then replace
          ASTNode newExp = ASTNode.copySubtree(ast, ast2);
          Utils.replaceChildInParent(node, newExp);
          didFold = true;
        }
      }
    }
  }

  /**
     * Replaces parenthesized literals in the tree with the literals.
     *
     * <p>top(root) := all nodes reachable from root such that each node
     * is an outermost infix expression that ends
     * in a number literal
     *
     * <p>topParents(root) := all nodes such that each one is the parent
     * of some node in top(root)
     *
     * @requires root != null
     * @requires (root instanceof CompilationUnit) \/ parent(root) != null
     *
     * @ensures fold(root) == !(old(top(root)) == \emptyset)
     *
     *
     * @ensure node.getOperator() == InfixExpression.Operator.PLUS
     * @ensure node.getLeftOperand() is a number literals
     * @ensure node.getRightOperand() is a number literals
     *
     *
     * @ensures \forall n \in old(top(root)),
     *     parent(old(bottom(n))) = old(parent(n)))
     *     /\ (and) children(old(parent(n))) =
     *     (old(children(parent(n))) \setminus {n}) \cup {old(bottom(n))}
     *
     * @ensures \forall n \in old(topParents(root)), parent(n) = old(parent(n))
     * @ensures top(root) = \emptyset
     *     /\ topParents = \emptyset
     * @param root the root of the tree to traverse.
     * @return true if number literals were replaced in the rooted tree
   * */
  @Override
  public boolean fold(final ASTNode root) {
    checkRequires(root);
    Visitor visitor = new Visitor();
    root.accept(visitor);
    return visitor.didFold;
  }

  private void checkRequires(final ASTNode root) {
    Utils.requiresNonNull(root, "Null root passed to "
            + "ParenthesizedExpressionFolding.fold");
    if (!(root instanceof CompilationUnit) && root.getParent() == null) {
      Utils.throwRuntimeException(
              "Non-CompilationUnit root with no parent passed "
                      + "to ParenthesizedExpressionFolding.fold"
      );
    }
  }
}
