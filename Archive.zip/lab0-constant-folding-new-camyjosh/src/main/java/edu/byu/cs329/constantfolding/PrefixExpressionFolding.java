package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PrefixExpressionFolding implements Folding {
  static final Logger log = LoggerFactory.getLogger(PrefixExpression.class);

  class Visitor extends ASTVisitor {
    public boolean didFold = false;

    private boolean isBooleanLiteral(ASTNode exp) {
      return exp instanceof BooleanLiteral;
    }

    @Override
    public void endVisit(PrefixExpression node) {
      if (node == null) {
        return;
      }
      // check for boolean literal
      if (node.getOperator() == PrefixExpression.Operator.NOT) {
        if (isBooleanLiteral(node.getOperand())) {
          // get operands
          BooleanLiteral exp = (BooleanLiteral) node.getOperand();
          // whatever in the operand
          boolean a = exp.booleanValue();

          //set to reverse value
          exp.setBooleanValue(!a);
          AST ast = node.getAST();
          // make it the top root
          ASTNode newExp = ASTNode.copySubtree(ast, exp);
          Utils.replaceChildInParent(node, newExp);
          didFold = true;
        }
      }
    }
  }

  /**
   * Replaces parenthesized literals in the tree with the literals.
   *
   * <p>top(root) := all nodes reachable from root such that each node
   * is an outermost not expression that ends
   * in a boolean literal
   *
   * <p>topParents(root) := all nodes such that each one is the parent
   * of some node in top(root)
   *
   * @requires root != null
   * @requires (root instanceof CompilationUnit) \/ parent(root) != null
   *
   * @ensures fold(root) == !(old(top(root)) == \emptyset)
   *
   *
   * @ensure node.getOperator() == PrefixExpression.Operator.NOT
   * @ensure node.getOperand is a boolean
   *
   *
   * @ensures \forall n \in old(top(root)),
   *     parent(old(bottom(n))) = old(parent(n)))
   *     /\ (and) children(old(parent(n))) =
   *     (old(children(parent(n))) \setminus {n}) \cup {old(bottom(n))}
   *
   * @ensures \forall n \in old(topParents(root)), parent(n) = old(parent(n))
   * @ensures top(root) = \emptyset
   *     /\ topParents = \emptyset
   * @param root the root of the tree to traverse.
   * @return true if number literals were replaced in the rooted tree
   * */
  @Override
  public boolean fold(ASTNode root) {
    checkRequires(root);
    Visitor visitor = new Visitor();
    root.accept(visitor);
    return visitor.didFold;
  }

  private void checkRequires(final ASTNode root) {
    Utils.requiresNonNull(root, "Null root passed "
            + "to ParenthesizedExpressionFolding.fold");

    if (!(root instanceof CompilationUnit) && root.getParent() == null) {
      Utils.throwRuntimeException(
              "Non-CompilationUnit root with no parent passed "
                      + "to ParenthesizedExpressionFolding.fold"
      );
    }
  }



}
