package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IfStatement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IfStatementFolding implements Folding {

  static final Logger log = LoggerFactory.getLogger(IfStatementFolding.class);

  class Visitor extends ASTVisitor {
    public boolean didFold = false;

    private boolean isBooleanLiteral(ASTNode exp) {
      return exp instanceof BooleanLiteral;
    }

    @Override
    public void endVisit(IfStatement node) {
      if (node == null) {
        return;
      }
      // get the condition of the if statement
      ASTNode exp = node.getExpression();
      /// check for if boolean literal
      // if boolean literal is false then we will want to remove
      if (!(exp instanceof BooleanLiteral)) {
        return;
      }
      BooleanLiteral bl = (BooleanLiteral) exp;
      if (bl.booleanValue()) {
        ASTNode newExp = ASTNode.copySubtree(node.getAST(), node.getThenStatement());
        Utils.replaceChildInParent(node, newExp);
      } else {
        if (node.getElseStatement() != null) {
          ASTNode newExp = ASTNode.copySubtree(node.getAST(), node.getThenStatement());
          Utils.replaceChildInParent(node, newExp);
        } else {
          Utils.removeChildInParent(node);
        }
      }
      didFold = true;
    }
  }

  /**
   * Replaces parenthesized literals in the tree with the literals.
   *
   * <p>top(root) := all nodes reachable from root such that each node
   * is an outermost operator expression that ends
   * in a boolean literal
   *
   * <p>topParents(root) := all nodes such that each one is the parent
   * of some node in top(root)
   *
   * @requires root != null
   * @requires (root instanceof CompilationUnit) \/ parent(root) != null
   *
   * @ensures fold(root) == !(old(top(root)) == \emptyset)
   *
   * @ensure node.getExpression() is a boolean literals
   *
   *
   * @ensures \forall n \in old(top(root)),
   *     parent(old(bottom(n))) = old(parent(n))) /\ (and) children(old(parent(n)))
   *     = (old(children(parent(n))) \setminus {n}) \cup {old(bottom(n))}
   *
   * @ensures \forall n \in old(topParents(root)), parent(n) = old(parent(n))
   * @ensures top(root) = \emptyset /\ topParents = \emptyset
   * @param root the root of the tree to traverse.
   * @return true if number literals were replaced in the rooted tree
   * */
  @Override
  public boolean fold(ASTNode root) {
    checkRequires(root);
    Visitor visitor = new Visitor();
    root.accept(visitor);
    return visitor.didFold;
  }

  private void checkRequires(final ASTNode root) {
    Utils.requiresNonNull(root, "Null root passed to "
            + "ParenthesizedExpressionFolding.fold");
    if (!(root instanceof CompilationUnit) && root.getParent() == null) {
      Utils.throwRuntimeException(
              "Non-CompilationUnit root with no parent passed "
                      + "to ParenthesizedExpressionFolding.fold"
      );
    }
  }
}
