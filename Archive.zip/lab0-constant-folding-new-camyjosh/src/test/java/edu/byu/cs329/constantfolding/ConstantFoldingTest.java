package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ConstantFoldingTest {
  ConstantFolding folderUnderTest = null;
  @BeforeEach
  void beforeEach() {folderUnderTest = new ConstantFolding();}

  @Test
  @DisplayName("Should throw RuntimeException when root is null")
  void should_ThrowRuntimeException_when_RootIsNull() {
    assertThrows(RuntimeException.class, ()-> {
      folderUnderTest.fold(null);
    });
  }

  @Test
  @DisplayName("Should throw Runtime Exception when root is not a Compilation Unit and has no parent")
  void should_ThrowRuntimeException_when_RootIsNotACompilationUnitAndHasNoParent() {
    assertThrows(RuntimeException.class, () -> {
      URI uri = Utils.getUri(this, "");
      ASTNode compilationUnit = Utils.getCompilationUnit(uri);
      ASTNode root = compilationUnit.getAST().newNullLiteral();
      folderUnderTest.fold(root);
    });
  }

  @Test
  @DisplayName("Should throw Runtime Exception when root is not a boolean literals")
  void should_ThrowRuntimeException_when_ExpressionIsNotBooleanLiteral() {
    assertThrows(RuntimeException.class, () -> {
      URI uri = Utils.getUri(this, "");
      ASTNode compilationUnit = Utils.getCompilationUnit(uri);
      ASTNode root = compilationUnit.getAST().newCharacterLiteral();
      folderUnderTest.fold(root);
    });
  }
  @Test
  @DisplayName("Should not fold the if branch if there is no boolean literal")
  void should_notFoldWhenNoBooleanLiteral() {
    String rootName = "ifStatements/should_notFoldIfStatement_original.java";
    String expectedName = "ifStatements/should_notFoldIfStatement_original.java";
    assertEquals(MoreUtils.getASTNodeFor(this, rootName), MoreUtils.getASTNodeFor(this,expectedName));
  }



}
