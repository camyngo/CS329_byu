package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Test for folding PrefixExpression types")
public class PrefixExpressionFoldingTests {
  PrefixExpressionFolding folderUnderTest=null;

  @BeforeEach
  void beforeEach() {
    folderUnderTest=new PrefixExpressionFolding();
  }

  @Test
  @DisplayName("Should throw RuntimeException when root is null")
  void should_ThrowRuntimeException_when_RootIsNull() {
    assertThrows(RuntimeException.class, () -> {
      folderUnderTest.fold(null);
    });
  }

  @Test
  @DisplayName("Should throw Runtime Exception when root is not a Compilation Unit and has no parent")
  void should_ThrowRuntimeException_when_RootIsNotACompilationUnitAndHasNoParent() {
    assertThrows(RuntimeException.class, () -> {
      URI uri=Utils.getUri(this, "");
      ASTNode compilationUnit=Utils.getCompilationUnit(uri);
      ASTNode root=compilationUnit.getAST().newBooleanLiteral(true);
      ASTNode exp=root.getParent();
      folderUnderTest.fold(root);
    });
  }

  @Test
  @DisplayName("Should not fold when there are no !")
  void should_NotFoldAnything_when_ThereAreNoParenthesizedLiterals() {
    String rootName = "prefixLiterals/NotPrefixFold.java";
    String expectedName = "prefixLiterals/NotPrefixFold.java";
    MoreUtils.assertDidNotFold(this, rootName, expectedName, folderUnderTest);
  }

  @Test
  @DisplayName("Should fold Prefix successfully")
  void should_Fold() {
    String rootName = "prefixLiterals/should_foldWhenAPrefix.java";
    String expectedName = "prefixLiterals/PrefixResult.java";
    MoreUtils.assertDidFold(this, rootName, expectedName, folderUnderTest);
  }
}

