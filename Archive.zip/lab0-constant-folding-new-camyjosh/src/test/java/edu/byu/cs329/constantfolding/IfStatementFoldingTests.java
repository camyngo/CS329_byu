package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Test for folding PrefixExpression types")
public class IfStatementFoldingTests {
  IfStatementFolding folderUnderTest = null;

  @BeforeEach
  void beforeEach() {folderUnderTest = new IfStatementFolding();}

  @Test
  @DisplayName("Should throw RuntimeException when root is null")
  void should_ThrowRuntimeException_when_RootIsNull() {
    assertThrows(RuntimeException.class, ()-> {
      folderUnderTest.fold(null);
    });
  }

  @Test
  @DisplayName("Should throw Runtime Exception when root is not a Compilation Unit and has no parent")
  void should_ThrowRuntimeException_when_RootIsNotACompilationUnitAndHasNoParent() {
    assertThrows(RuntimeException.class, () -> {
      URI uri = Utils.getUri(this, "");
      ASTNode compilationUnit = Utils.getCompilationUnit(uri);
      ASTNode root = compilationUnit.getAST().newNullLiteral();
      folderUnderTest.fold(root);
    });
  }

  @Test
  @DisplayName("Should throw Runtime Exception when root is not a boolean literals")
  void should_ThrowRuntimeException_when_ExpressionIsNotBooleanLiteral() {
    assertThrows(RuntimeException.class, () -> {
      URI uri = Utils.getUri(this, "");
      ASTNode compilationUnit = Utils.getCompilationUnit(uri);
      ASTNode root = compilationUnit.getAST().newCharacterLiteral();
      folderUnderTest.fold(root);
    });
  }

    @Test
    @DisplayName("Should fold the if branch if there is a boolean literal")
    void should_foldWhenBooleanLiteral() {
      String rootName = "ifStatements/should_foldIfStatement_original.java";
      String expectedName = "ifStatements/should_FoldIfStatement_folded.java";
      MoreUtils.assertDidFold(this, rootName, expectedName, folderUnderTest);
    }

    @Test
    @DisplayName("Should not fold the if branch if there is no boolean literal")
    void should_notFoldWhenNoBooleanLiteral() {
      String rootName = "ifStatements/should_notFoldIfStatement_original.java";
      String expectedName = "ifStatements/should_notFoldIfStatement_original.java";
      MoreUtils.assertDidNotFold(this, rootName, expectedName, folderUnderTest);
    }
}