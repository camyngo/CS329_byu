package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Tests for folding InfixExpression types")
public class InfixExpressionFoldingTest {
  InfixExpressionFolding folderUnderTest = null;

  @BeforeEach
  void beforeEach() {
    folderUnderTest = new InfixExpressionFolding();
  }

  @Test
  @DisplayName("Should throw RuntimeException when root is null")
  void should_ThrowRuntimeException_when_RootIsNull() {
    assertThrows(RuntimeException.class, () -> {
      folderUnderTest.fold(null);
    });
  }

  @Test
  @DisplayName("Should throw RuntimeException when root is not a CompilationUnit and has no parent")
  void should_ThrowRuntimeException_when_RootIsNotACompilationUnitAndHasNoParent() {
    assertThrows(RuntimeException.class, () -> {
      URI uri = Utils.getUri(this, "");
      ASTNode compilationUnit = Utils.getCompilationUnit(uri);
      ASTNode root = compilationUnit.getAST().newNullLiteral();
      folderUnderTest.fold(root);
    });
  }

  @Test
  @DisplayName("Should not fold when not InFixExpression plus")
  void should_NotFold_when_givenNumberLiterals() {
    String rootName = "InfixLiterals/InfixFileNotAdd.java";
    String expectedName = "InfixLiterals/InfixFileNotAdd.java";
    MoreUtils.assertDidNotFold(this, rootName, expectedName, folderUnderTest);
  }

  @Test
  @DisplayName("Should fold when not InFixExpression plus")
  void should_Fold_when_givenNumberLiterals() {
    String rootName = "InfixLiterals/InfixFileAddAfterFold.java";
    String expectedName = "InfixLiterals/InfixAddResult.java";
    MoreUtils.assertDidFold(this, rootName, expectedName, folderUnderTest);
  }




}
