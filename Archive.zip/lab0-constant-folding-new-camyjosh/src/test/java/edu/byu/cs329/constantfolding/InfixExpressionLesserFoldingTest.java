package edu.byu.cs329.constantfolding;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Tests for folding InfixExpression types")
public class InfixExpressionLesserFoldingTest {
  InfixExpressionFoldingLesser folderUnderTest = null;

  @BeforeEach
  void beforeEach() {
    folderUnderTest = new InfixExpressionFoldingLesser();
  }

  @Test
  @DisplayName("Should throw RuntimeException when root is null")
  void should_ThrowRuntimeException_when_RootIsNull() {
    assertThrows(RuntimeException.class, () -> {
      folderUnderTest.fold(null);
    });
  }

  @Test
  @DisplayName("Should throw RuntimeException when root is not a CompilationUnit and has no parent")
  void should_ThrowRuntimeException_when_RootIsNotACompilationUnitAndHasNoParent() {
    assertThrows(RuntimeException.class, () -> {
      URI uri = Utils.getUri(this, "");
      ASTNode compilationUnit = Utils.getCompilationUnit(uri);
      ASTNode root = compilationUnit.getAST().newNullLiteral();
      folderUnderTest.fold(root);
    });
  }


  @Test
  @DisplayName("Should not fold")
  void should_NotFold_when_givenNumberLiterals_For_Not_Lesser() {
    String rootName = "InfixLiterals/InfixNotLesser.java";
    String expectedName = "InfixLiterals/InfixNotLesser.java";
    MoreUtils.assertDidNotFold(this, rootName, expectedName, folderUnderTest);
  }

  @Test
  @DisplayName("Should fold")
  void should_Fold_when_givenNumberLiterals_For_Not_Lesser() {
    String rootName = "InfixLiterals/InfixLesserAfterFold.java";
    String expectedName = "InfixLiterals/InfixLesserResult.java";
    MoreUtils.assertDidFold(this, rootName, expectedName, folderUnderTest);
  }




}
