public class ifstatement_original {
    public int name() {
      int x;
      {
        return x = 2;
      }
    }
}