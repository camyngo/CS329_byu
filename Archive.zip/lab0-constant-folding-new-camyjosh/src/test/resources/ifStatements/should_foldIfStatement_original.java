public class ifstatement_original {
    public int name() {
      int x;
        if (true) {
            return x = 2;
        }
        else{
          return 1;
        }
    }
}