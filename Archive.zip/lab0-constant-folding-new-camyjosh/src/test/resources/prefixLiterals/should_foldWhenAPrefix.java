public class PrefixFold{
  public void main() {
    boolean a = !true;
    return a = false;
  }
}