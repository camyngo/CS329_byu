public class NotFold{
  public void main() {
    private boolean x = true;
  }
}