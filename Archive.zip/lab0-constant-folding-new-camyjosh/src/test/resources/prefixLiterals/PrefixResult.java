public class PrefixFold{
  public void main() {
    boolean a = false;
    return a = false;
  }
}