package InfixLiterals;

public class InfixAddResult {
  public void main() {
    final int x = 7;
    return x;
  }
}