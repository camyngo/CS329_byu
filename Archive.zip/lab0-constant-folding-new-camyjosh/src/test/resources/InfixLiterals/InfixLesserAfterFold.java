package InfixLiterals;
public class InfixLesserAfterFold {
	public void main () {
			boolean x = 3 < 4;
			return x;
	}
}