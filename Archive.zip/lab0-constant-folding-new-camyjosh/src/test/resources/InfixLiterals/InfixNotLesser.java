public class InfixLesser {
  private boolean x = 3 > 4;
  return x;
}