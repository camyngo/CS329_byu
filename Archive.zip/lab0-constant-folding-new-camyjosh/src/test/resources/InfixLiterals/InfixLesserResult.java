package InfixLiterals;
public class InfixLesserAfterFold {
  public void main () {
        boolean x = true;
        return x;
  }
}

