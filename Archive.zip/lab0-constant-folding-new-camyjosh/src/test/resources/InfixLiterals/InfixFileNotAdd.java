package InfixLiterals;

public class InfixFileAdd {
  final int x = 3 * 4;
    return x;

}