package edu.byu.cs329.mcdc;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

public class CoverageTest {
  @Test
  @DisplayName("F function coverage testings")
  void testCoverageforF(){
    // Contrainst for C and A
    assertEquals(McDcTest.f(false, false,false, true), false);
    assertEquals(McDcTest.f(false, false, true, true), true);
    assertEquals(McDcTest.f(true, true, false, true), true);
    // contrainst on B with D as the same value
    assertEquals(McDcTest.f(true, true, false, false), true);
    assertEquals(McDcTest.f(true, false, false, false), false);

  }

  @Test
  @DisplayName("F function coverage testings")
  void testNotCoverageforF(){
    // Contrainst for C and A
    assertEquals(McDcTest.f(false, false,false, false), false);
    assertEquals(McDcTest.f(true, true, true, true), true);
    // contrainst on B with D as the same value
    assertEquals(McDcTest.f(false, true, false, true), false);
    assertEquals(McDcTest.f(true, false, true, false), false);

  }

  @Test
  @DisplayName("SortFunction Coverage")
  void testCoverageSort() {
    int[] unsortedArray = new int[]{2, 1, 4, 5, 4};

    int expectedSize = 1;
    Assertions.assertEquals(expectedSize, McDcTest.sort(unsortedArray, 1, 1).length);
    Assertions.assertEquals(expectedSize, McDcTest.sort(unsortedArray, 2, 1).length);
    Assertions.assertTrue(isSorted(McDcTest.sort(new int[]{1, 2, 3, 4, 5}, 0, 4)));
    Assertions.assertTrue(isSorted(McDcTest.sort(unsortedArray, 0, 4)));
  }

  public static boolean isSorted(int[] array) {
    for (int i = 0; i < array.length - 1; i++) {
      if (array[i] > array[i + 1])
        return false;
    }
    return true;
  }
}
