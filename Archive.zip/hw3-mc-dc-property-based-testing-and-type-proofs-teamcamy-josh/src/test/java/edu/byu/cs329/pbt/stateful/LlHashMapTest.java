package edu.byu.cs329.pbt.stateful;
import edu.byu.cs329.hashtable.LlHashMap;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Stream;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


/**
 * Test suite for the hash table.
 */
public class LlHashMapTest {

  static Logger logger = LoggerFactory.getLogger(LlHashMapTest.class);

  static final int NUM_TESTS = 5;
  static final int MAX_INT_VALUE = 50;
  static final int MAX_METHODS_CALL = 10;
  static final int MAX_METHODS = 2;
  static final int ADD_METHOD = 0;
  static final int REMOVE_METHOD = 1;
  static Random rand = new Random();

  static void applyRandomMethod(LlHashMap a, LlHashMap b) {
    for(int i = 0; i < MAX_METHODS_CALL; i++){
      int x = rand.nextInt(MAX_INT_VALUE);
      int methodID = rand.nextInt(MAX_METHODS);
      if (methodID == ADD_METHOD){
        a.put(i , x);
        b.put(i, x);
        logger.info("Add Element "+ x);
      } else if (methodID == REMOVE_METHOD){
        a.remove(i);
        b.remove(i);
        logger.info("Remove Element "+ x);
      }
    }
  }
  static void applyRandomMethod(LlHashMap a, HashMap<Integer, Integer> oracle) {
    for(int i = 0; i < MAX_METHODS_CALL; i++){
      int x = rand.nextInt(MAX_INT_VALUE);
      int methodID = rand.nextInt(MAX_METHODS);
      if (methodID == ADD_METHOD){
        a.put(i , x);
        oracle.put(i, x);
        logger.info("Add Element "+ x);
      } else if (methodID == REMOVE_METHOD){
        a.remove(i);
        oracle.remove(i);
        logger.info("Remove Element "+ x);
      }
    }
  }

  static Stream<Arguments> createHashMapAndOracle() {
    ArrayList<Arguments> args = new ArrayList<Arguments>();
    for(int i = 0; i < NUM_TESTS; i++ ){
      LlHashMap a = new LlHashMap(MAX_METHODS_CALL);
      HashMap<Integer, Integer> oracle = new HashMap<>();
      args.add(Arguments.of(a,oracle));
    }
    return args.stream();
  }

  static Stream<Arguments> createTwoHashMap() {
    ArrayList<Arguments> args = new ArrayList<Arguments>();
    for(int i = 0; i < NUM_TESTS; i++ ){
      LlHashMap a = new LlHashMap(MAX_METHODS_CALL);
      LlHashMap b = new LlHashMap(MAX_METHODS_CALL);
      args.add(Arguments.of(a,b));
    }
    return args.stream();
  }

  @ParameterizedTest
  @DisplayName("Test no exceptions for 2 Llhashmap")
  @MethodSource("createTwoHashMap")
  void testNoExceptions(LlHashMap a, LlHashMap b){
    Assertions.assertDoesNotThrow(() -> { applyRandomMethod(a, b); } );
  }

  @ParameterizedTest()
  @DisplayName("Test no exceptions for Llhashmap and oracle")
  @MethodSource("createHashMapAndOracle")
  void testNoExceptions(LlHashMap a, HashMap<Integer, Integer> oracle){
    Assertions.assertDoesNotThrow(() -> { applyRandomMethod(a, oracle); } );
  }

  @Test
  @DisplayName("Test to see how LLhashmap working with Hashmap")
  void HashMap(){
    LlHashMap map = new LlHashMap(NUM_TESTS);
    HashMap<Integer, Integer> hmap = new HashMap<>();
    for(int i = 0; i < NUM_TESTS; i++ ){
      int x = rand.nextInt(MAX_INT_VALUE);
      map.put(i, x);
      hmap.put(i, x);
    }
    hmap.remove(2);
    map.remove(2);
  }

  @ParameterizedTest()
  @DisplayName("Test equivalence with oracle")
  @MethodSource("createHashMapAndOracle")
  void testEquals(LlHashMap a, HashMap<Integer, Integer> oracle){
    applyRandomMethod(a, oracle);
    for(Integer key : oracle.keySet()){
      if(a.contains(key)) {
        assertEquals(a.get(key), oracle.get(key));
      }
    }
  }

  @ParameterizedTest
  @DisplayName("Test equivalence for 2 Llhashmap")
  @MethodSource("createTwoHashMap")
  void testEquals(LlHashMap a, LlHashMap b){
    applyRandomMethod(a, b);
    a.equals(b);
  }

  @ParameterizedTest(name = "Test double add and see if a and b still equivalence")
  @DisplayName("Test equivalence for 2 Llhashmap")
  @MethodSource("createTwoHashMap")
  void testAddElement(LlHashMap a, LlHashMap b){
    applyRandomMethod(a, b);
    // run random prefix
    // max capacity is only 10
    int x = rand.nextInt(5);
    int y = rand.nextInt(MAX_INT_VALUE);
    a.put(x, y);
    b.put(x,y);
    b.put(x,y);
    applyRandomMethod(a, b);
    testEquals(a,b);
  }

  @ParameterizedTest(name = "Test double remove and see if a and b still equivalence")
  @DisplayName("Test equivalence for 2 Llhashmap")
  @MethodSource("createTwoHashMap")
  void testRemoveElement(LlHashMap a, LlHashMap b){
    applyRandomMethod(a, b);
    // run random prefix
    int x = rand.nextInt(5);
    int y = rand.nextInt(MAX_INT_VALUE);
    a.put(x, y);
    a.remove(x);
    a.remove(x);

    b.put(x, y);
    b.remove(x);
    applyRandomMethod(a, b);
    testEquals(a,b);
  }

  @ParameterizedTest(name = "No integer that not in a equivalent to add then remove")
  @DisplayName("Test Add then remove element")
  @MethodSource("createTwoHashMap")
  void testRemoveElement2(LlHashMap a, LlHashMap b){
    applyRandomMethod(a, b);
    // run random prefix
    int x = rand.nextInt(MAX_INT_VALUE);
    while (a.contains(x) && !a.equals(null)){
      // pick a new number
      x = rand.nextInt(MAX_INT_VALUE);
    }
    // because max capacity is only 10
    int y = rand.nextInt(8);
    b.put(y,x);
    b.remove(y);
    applyRandomMethod(a, b);
    testEquals(a,b);
  }
}
