package edu.byu.cs329.pbt.stateless;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BinarySearchTest {
  public static Random rand = new Random();
  int MAX_ARRAY_SIZE = 50;

  /**
   * cs329.requires: 
   *    array is non null.
   *    array is sorted by increasing value: 
   *       \forall i, 0 < i < array.length - 1 implies array[i] < array[i+1]
   * cs329.ensures:  
   *       true if an only if \exists i, 0 <= i < array.length /\ value == array[i]
   **/
  public static boolean search(int[] array, int value) {
    // add error checking
    if(array == null || array.length == 0 || !isSorted(array)) {
      return false;
    }
    int left = 0;
    int right = array.length - 1;
    int index = (right + left) / 2;

    while (left <= right) {
      if (array[index] == value){
        return true;
      }
      if (array[index] < value) {
        left = index + 1;
      }
      else {
        right = index - 1;
      }

      index = (right + left) / 2;

    }
    return false;
  }

  public static boolean isSorted(int[] array) {
    for (int i = 0; i < array.length - 1; i++) {
      if (array[i] > array[i + 1])
        return false;
    }
    return true;
  }

  public Stream<Arguments> generate() {
    int min = -9999;
    int max = 9999;
    ArrayList<Arguments> result = new ArrayList<>();

    // edge cases
    result.add(Arguments.of(new ArrayList<Integer>())); // empty array
    result.add(Arguments.of((Object) null)); // null

    // 5 unsorted array - all positive
    for (int i = 0; i < 5; i++) {
      int size = getRandomNumberRange(0, MAX_ARRAY_SIZE);
      ArrayList<Integer> currentList = new ArrayList<>();
      for (int a = 0; a < size; a++) {
        int ranNum = getRandomNumberRange(0, max);
        currentList.add(ranNum);
      }
      result.add(Arguments.of(currentList));
    }

    // 5 unsorted array - all negative
    for (int i = 0; i < 5; i++) {
      int size = getRandomNumberRange(0, MAX_ARRAY_SIZE);
      ArrayList<Integer> currentList = new ArrayList<>();
      for (int a = 0; a < size; a++) {
        int ranNum = getRandomNumberRange(min, 0);
        currentList.add(ranNum);
      }
      result.add(Arguments.of(currentList));
    }

    // 5 unsorted array - mixed
    for (int i = 0; i < 5; i++) {
      int size = getRandomNumberRange(0, MAX_ARRAY_SIZE);
      ArrayList<Integer> currentList = new ArrayList<>();
      for (int a = 0; a < size; a++) {
        int ranNum = getRandomNumberRange(min, max);
        currentList.add(ranNum);
      }
      result.add(Arguments.of(currentList));
    }

    ArrayList<ArrayList<Integer>> sortedArrays = new ArrayList<>();

    // 5 sorted array - all positive
    for (int i = 0; i < 5; i++) {
      int size = getRandomNumberRange(0, MAX_ARRAY_SIZE);
      ArrayList<Integer> currentList = new ArrayList<>();
      for (int a = 0; a < size; a++) {
        int prevNum = getRandomNumberRange(0, max);
        if (a != 0) {
          prevNum = currentList.get(a - 1);
        }
        int ranNum = getRandomNumberBigger(prevNum);
        currentList.add(ranNum);
      }
      result.add(Arguments.of(currentList));
      sortedArrays.add(currentList);
    }

    // 5 sorted array - all negative
    for (int i = 0; i < 5; i++) {
      int size = getRandomNumberRange(0, MAX_ARRAY_SIZE);
      ArrayList<Integer> currentList = new ArrayList<>();
      for (int a = 0; a < size; a++) {
        int prevNum = getRandomNumberRange(min, 0);
        if (a != 0) {
          prevNum = currentList.get(a - 1);
        }
        int ranNum = getRandomNumberBigger(prevNum);
        currentList.add(ranNum);
      }
      result.add(Arguments.of(currentList));
      sortedArrays.add(currentList);
    }

    // 5 sorted array - mixed
    for (int i = 0; i < 5; i++) {
      int size = getRandomNumberRange(0, MAX_ARRAY_SIZE);
      ArrayList<Integer> currentList = new ArrayList<>();
      for (int a = 0; a < size; a++) {
        int prevNum = getRandomNumberRange(min, 0);
        if (a != 0) {
          prevNum = currentList.get(a - 1);
        }
        int ranNum = getRandomNumberBigger(prevNum);
        currentList.add(ranNum);
      }
      result.add(Arguments.of(currentList));
      sortedArrays.add(currentList);
    }

    // reverse all 15 sorted arrays and to make it in reversed order
    for (ArrayList<Integer> current : sortedArrays) {
      Collections.reverse(current);
      result.add(Arguments.of(current));
    }

    // add duplicate numbers to the list
    ArrayList<Integer> duplicate1 = new ArrayList<>();
    duplicate1.add(1);
    duplicate1.add(1);
    duplicate1.add(1);
    duplicate1.add(1);
    duplicate1.add(1);
    duplicate1.add(1);

    ArrayList<Integer> duplicate2 = new ArrayList<>();
    duplicate2.add(-1);
    duplicate2.add(-1);
    duplicate2.add(1);
    duplicate2.add(1);
    duplicate2.add(2);
    duplicate2.add(2);

    ArrayList<Integer> duplicate3 = new ArrayList<>();
    duplicate3.add(0);
    duplicate3.add(1);
    duplicate3.add(2);
    duplicate3.add(3);
    duplicate3.add(4);
    duplicate3.add(4);

    result.add(Arguments.of(duplicate1));
    result.add(Arguments.of(duplicate2));
    result.add(Arguments.of(duplicate3));

    // there are 45 arrays
    return result.stream();
  }

  public int getRandomNumberRange(int min, int max) {
    return (int) ((Math.random() * (max - min)) + min);
  }

  public int getRandomNumberBigger(int min) {
    return (int) ((Math.random() * (100)) + min);
  }

  @ParameterizedTest
  @MethodSource("generate")
  public void CheckBinarySearchAlgorithm(ArrayList<Integer> input) {
    int num = 0;
    boolean contain = false;
    int[] inputArray = null;
    if (input != null && input.size() != 0) {
//      int ranIndex = getRandomNumberRange(0, input.size() - 1);
      num = getRandomNumberBigger(-9999);
      inputArray = Arrays.stream(input.toArray(new Integer[0])).mapToInt(Integer::intValue).toArray();
      if (isSorted(inputArray)) {
        contain = input.contains(num);
      }
    }
    boolean actual = search(inputArray, num);
    Assertions.assertEquals(contain, actual);
  }



}

