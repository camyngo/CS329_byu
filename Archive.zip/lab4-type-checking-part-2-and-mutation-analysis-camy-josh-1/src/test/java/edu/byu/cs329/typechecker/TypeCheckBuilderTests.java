package edu.byu.cs329.typechecker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests for TypeCheckerBuilder")
public class TypeCheckBuilderTests {
  static final Logger log = LoggerFactory.getLogger(TypeCheckBuilderTests.class);
  SymbolTableBuilder stb = null;

  @BeforeEach
  void beforeEach() {
    stb = new SymbolTableBuilder();
  }

  private boolean getTypeChecker(final String fileName, List<DynamicNode> tests) {
    ASTNode compilationUnit = Utils.getAstNodeFor(this, fileName);
    SymbolTableBuilder symbolTableBuilder = new SymbolTableBuilder();
    ISymbolTable symbolTable = symbolTableBuilder.getSymbolTable(compilationUnit);
    TypeCheckBuilder typeCheckerBuilder = new TypeCheckBuilder();
    return typeCheckerBuilder.getTypeChecker(symbolTable, compilationUnit, tests);
  }

  @TestFactory
  @DisplayName("Should prove type safe when given empty class")
  Stream<DynamicNode> should_proveTypeSafe_when_givenEmptyClass() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenEmptyClass.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Should prove type safe when given empty method")
  Stream<DynamicNode> should_proveTypeSafe_when_givenEmptyMethod() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenEmptyMethod.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Should prove type safe when given empty block")
  Stream<DynamicNode> should_proveTypeSafe_when_givenEmptyBlock() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenEmptyBlock.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Should prove type safe when given variable declarations no inits")
  Stream<DynamicNode> should_proveTypeSafe_when_givenVariableDeclrationsNoInits() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenVariableDeclrationsNoInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Should prove type safe when given variable declarations with compatible inits")
  Stream<DynamicNode> should_proveTypeSafe_when_givenVariableDeclrationsWithCompatibleInits() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenVariableDeclrationsWithCompatibleInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    // test the tests
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Should not prove type safe when given bad inits")
  Stream<DynamicNode> should_NotProveTypeSafe_when_givenBadInits() {
    String fileName = "typeChecker/should_NotProveTypeSafe_when_givenBadInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);

    // Toggle as desired
    // 
    // Option 1: mvn exec:java shows the details of the typeproof for visual inspection
    // return tests.stream();
    //
    // Option 2: test only isNotTypeSafe and show no details
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);
    return Arrays.asList((DynamicNode)test).stream();
  }

  @TestFactory
  @DisplayName("Field Access Test")
  Stream<DynamicNode> should_ProveTypeSafe_FieldAccess() {
    String fileName ="fieldaccessTest/should_proveFieldAccess_withParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Field Access Test")
  Stream<DynamicNode> should_ProveTypeSafe_FieldAccess_WihtoutParams() {
    String fileName ="fieldaccessTest/should_proveFieldAccess_withParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Field Access Test")
  Stream<DynamicNode> should_NotProveTypeSafe_FieldAccess_WithParams() {
    String fileName ="fieldaccessTest/Should_failFieldAccess.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);
    return Arrays.asList((DynamicNode)test).stream();
  }

  @TestFactory
  @DisplayName("Method Invocation Test - No Parameter")
  Stream<DynamicNode> should_ProveTypeSafe_MethodInvocation_NoParameter() {
    String fileName ="MethodInvocationTest/should_invoke_method.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Method Invocation Test - One Parameter")
  Stream<DynamicNode> should_ProveTypeSafe_MethodInvocation_OneParameter() {
    String fileName ="MethodInvocationTest/should_invoke_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("If Statement - Parameter")
  Stream<DynamicNode> should_ProveTypeSafe_IfStatement_Parameter() {
    String fileName ="ifStatement/should_proveIfStatement_withparameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("If Statement - Failed")
  Stream<DynamicNode> shouldNot_ProveTypeSafe_IfStatement() {
    String fileName = "ifStatement/should_notproveIfStatement.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);
    return Arrays.asList((DynamicNode)test).stream();
  }

  @TestFactory
  @DisplayName("While Statement - NoParameter")
  Stream<DynamicNode> should_ProveTypeSafe_WhileStatement_NoParameter() {
    String fileName ="whileStatement/should_proveWhileStatement_withoutParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("While Statement - Failed")
  Stream<DynamicNode> shouldNot_ProveTypeSafe_WhileStatement() {
    String fileName = "other/should_NotProveWhileStatement.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);
    return Arrays.asList((DynamicNode)test).stream();
  }

  @TestFactory
  @DisplayName("Infix - BOOL - TypeSafe")
  Stream<DynamicNode> should_Prove_Infix_Bool() {
    String fileName = "InfixExpression_boolean/should_proveTypeSafe_infix_NoParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix - Int - TypeSafe")
  Stream<DynamicNode> should_Prove_Infix_int() {
    String fileName = "infixExpression_int/should_proveTypeSafe_infix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix - final - TypeSafe")
  Stream<DynamicNode> should_Prove_Infix_final() {
    String fileName = "InfixExpression_boolean/should__proveTypeSafe_infix.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix - bothboolean - TypeSafe")
  Stream<DynamicNode> should_Prove_Infix_bothboolean() {
    String fileName = "InfixExpression_boolean/should_proveTypeSafe_infix_both_boolean.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix - fail")
  Stream<DynamicNode> should_NotProve_Infix() {
    String fileName = "infixExpression_int/should_notProve_infix_type.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);
    return Arrays.asList((DynamicNode)test).stream();
  }

  @TestFactory
  @DisplayName("Invoke - fail")
  Stream<DynamicNode> should_NotProve_methodInvoke() {
    String fileName = "MethodInvocationTest/should_not_invoke.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);
    return Arrays.asList((DynamicNode)test).stream();
  }

  @TestFactory
  @DisplayName("Prefix - parameter - TypeSafe")
  Stream<DynamicNode> should_Prove_prefix_parameter() {
    String fileName = "other/prefixExpression/should_proveTypeSafe_prefix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Prefix - returnBool - TypeSafe")
  Stream<DynamicNode> should_Prove_prefix_returnBool() {
    String fileName = "other/prefixExpression/should_proveTypeSafe_prefix_returnBoolean.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("ExpressionStatement - everything - TypeSafe")
  Stream<DynamicNode> should_Prove_expressionStatement_everything() {
    String fileName = "expressionStatement/should_proveTypeSafe_expression_addition.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    return tests.stream();
  }



}
