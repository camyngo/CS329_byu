package edu.byu.cs329.typechecker;

import org.opentest4j.AssertionFailedError;
import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

public class dynamicTest {
  static final Logger log = LoggerFactory.getLogger(TypeCheckBuilderTests.class);
  SymbolTableBuilder stb = null;
  @BeforeEach
  void beforeEach() {
    stb = new SymbolTableBuilder();
  }

  private boolean getTypeChecker(final String fileName, List<DynamicNode> tests) {
    ASTNode compilationUnit = Utils.getAstNodeFor(this, fileName);
    SymbolTableBuilder symbolTableBuilder = new SymbolTableBuilder();
    ISymbolTable symbolTable = symbolTableBuilder.getSymbolTable(compilationUnit);
    TypeCheckBuilder typeCheckerBuilder = new TypeCheckBuilder();
    return typeCheckerBuilder.getTypeChecker(symbolTable, compilationUnit, tests);
  }

  //code to help iterate through all the DynamicContainers and DynamicTests:
  void addNodeAndChildren(DynamicNode node, List<DynamicNode> list) {
    list.add(node);
    if (node instanceof DynamicContainer) {
      DynamicContainer container = (DynamicContainer)node;
      Iterator<? extends DynamicNode> children = container.getChildren().iterator();
      while (children.hasNext()) {
        addNodeAndChildren(children.next(), list);
      }
    }
  }
  List<DynamicNode> buildListOfDynamicNodes(List<DynamicNode> proof) {
    List<DynamicNode> allNodes = new ArrayList<>();
    addNodeAndChildren(proof.get(0), allNodes);
    return allNodes;
  }

  @Test
  @DisplayName("Should prove type safe when given empty class")
  void should_proveTypeSafe_when_givenEmptyClass() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenEmptyClass.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    Assertions.assertTrue(isTypeSafe);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    assertTrue(inOrder.get(2) instanceof DynamicTest);
    DynamicTest t = (DynamicTest) inOrder.get(3);
    Assertions.assertDoesNotThrow(t.getExecutable());
    Assertions.assertTrue(t instanceof DynamicTest);
    assertEquals(t.getDisplayName(), "void = void");

    assertEquals(inOrder.size(), 4);

  }

  @Test
  @DisplayName("Should prove type safe when given empty method")
  void should_proveTypeSafe_when_givenEmptyMethod() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenEmptyMethod.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    DynamicContainer test3th = (DynamicContainer) inOrder.get(3);
    Assertions.assertTrue(test3th instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    assertTrue(inOrder.get(4) instanceof DynamicTest);
    assertTrue(inOrder.get(5) instanceof DynamicTest);

    DynamicTest test5th = (DynamicTest) inOrder.get(5);
    Assertions.assertDoesNotThrow(test5th.getExecutable());
    Assertions.assertTrue(test5th instanceof DynamicTest);

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    assertTrue(inOrder.get(7) instanceof DynamicTest);

    assertEquals(inOrder.size(), 8);

  }

  @Test
  @DisplayName("Should prove type safe when given empty block")
  void should_proveTypeSafe_when_givenEmptyBlock() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenEmptyBlock.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    assertTrue(inOrder.get(4) instanceof DynamicTest);
    DynamicContainer test4th = (DynamicContainer) inOrder.get(3);
    Assertions.assertTrue(test4th instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");


    assertTrue(inOrder.get(5) instanceof DynamicTest);

    DynamicTest test5th = (DynamicTest) inOrder.get(5);
    Assertions.assertDoesNotThrow(test5th.getExecutable());
    Assertions.assertTrue(test5th instanceof DynamicTest);

    assertTrue(inOrder.get(6) instanceof DynamicTest);

    DynamicTest test6th = (DynamicTest) inOrder.get(6);
    Assertions.assertDoesNotThrow(test6th.getExecutable());
    Assertions.assertTrue(test6th instanceof DynamicTest);

    assertTrue(inOrder.get(7) instanceof DynamicTest);
    assertEquals(inOrder.size(), 8);


  }

  @Test
  @DisplayName("Should prove type safe when given variable declarations no inits")
  void should_proveTypeSafe_when_givenVariableDeclrationsNoInits() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenVariableDeclrationsNoInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);

    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    DynamicTest test6th = (DynamicTest) inOrder.get(6);
    Assertions.assertDoesNotThrow(test6th.getExecutable());
    Assertions.assertTrue(test6th instanceof DynamicTest);


    assertTrue(inOrder.get(9) instanceof DynamicTest);
    assertTrue(inOrder.get(12) instanceof DynamicTest);
    assertTrue(inOrder.get(13) instanceof DynamicTest);
    assertTrue(inOrder.get(14) instanceof DynamicTest);
    assertTrue(inOrder.get(15) instanceof DynamicTest);
    assertTrue(inOrder.get(16) instanceof DynamicTest);
    assertEquals(inOrder.size(), 17);

  }

  @Test
  @DisplayName("Should prove type safe when given variable declarations with compatible inits")
  void should_proveTypeSafe_when_givenVariableDeclrationsWithCompatibleInits() {
    String fileName = "typeChecker/should_proveTypeSafe_when_givenVariableDeclrationsWithCompatibleInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    // test the tests
    assertEquals(tests.size(), 2);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    DynamicTest test6th = (DynamicTest) inOrder.get(6);
    Assertions.assertDoesNotThrow(test6th.getExecutable());
    Assertions.assertTrue(test6th instanceof DynamicTest);

    assertTrue(inOrder.get(9) instanceof DynamicTest);
    assertTrue(inOrder.get(12) instanceof DynamicTest);
    assertTrue(inOrder.get(14) instanceof DynamicTest);
    assertTrue(inOrder.get(15) instanceof DynamicTest);
    assertEquals(inOrder.size(), 38);

  }

  @Test
  @DisplayName("Should not prove type safe when given bad inits")
  void should_NotProveTypeSafe_when_givenBadInits() {
    String fileName = "typeChecker/should_NotProveTypeSafe_when_givenBadInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);

    // Toggle as desired
    //
    // Option 1: mvn exec:java shows the details of the typeproof for visual inspection
    // return tests.stream();
    //
    // Option 2: test only isNotTypeSafe and show no details
    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:ERROR");

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    DynamicTest test6th = (DynamicTest) inOrder.get(6);
    Assertions.assertDoesNotThrow(test6th.getExecutable());
    Assertions.assertTrue(test6th instanceof DynamicTest);
    assertEquals(inOrder.size(), 32);


  }

  @Test
  @DisplayName("Field Access Test")
  void should_ProveTypeSafe_FieldAccess() {
    String fileName ="fieldaccessTest/should_proveFieldAccess_withParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    assertEquals(tests.size(), 2);
    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    DynamicTest test6th = (DynamicTest) inOrder.get(6);
    Assertions.assertDoesNotThrow(test6th.getExecutable());
    Assertions.assertTrue(test6th instanceof DynamicTest);

    assertTrue(inOrder.get(8) instanceof DynamicTest);
    assertTrue(inOrder.get(11) instanceof DynamicTest);
    assertTrue(inOrder.get(14) instanceof DynamicTest);
    assertTrue(inOrder.get(16) instanceof DynamicTest);
    assertTrue(inOrder.get(19) instanceof DynamicTest);
    assertTrue(inOrder.get(20) instanceof DynamicTest);
    assertTrue(inOrder.get(23) instanceof DynamicTest);
    assertTrue(inOrder.get(24) instanceof DynamicTest);
    assertEquals(inOrder.size(), 25);

  }

  @Test
  @DisplayName("Field Access Test")
  void should_ProveTypeSafe_FieldAccess_WihtoutParams() {
    String fileName ="fieldaccessTest/should_proveFieldAccess_withParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    assertEquals(tests.size(), 2);
    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:void");

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    DynamicTest test6th = (DynamicTest) inOrder.get(6);
    Assertions.assertDoesNotThrow(test6th.getExecutable());
    Assertions.assertTrue(test6th instanceof DynamicTest);

    assertTrue(inOrder.get(8) instanceof DynamicTest);
    assertTrue(inOrder.get(11) instanceof DynamicTest);
    assertTrue(inOrder.get(14) instanceof DynamicTest);
    assertTrue(inOrder.get(16) instanceof DynamicTest);
    assertTrue(inOrder.get(19) instanceof DynamicTest);
    assertTrue(inOrder.get(20) instanceof DynamicTest);
    assertTrue(inOrder.get(23) instanceof DynamicTest);
    assertTrue(inOrder.get(24) instanceof DynamicTest);
    assertEquals(inOrder.size(), 25);

  }


  @Test
  @DisplayName("Field Access Test")
  void should_NotProveTypeSafe_FieldAccess_WithParams() {
    String fileName ="fieldaccessTest/Should_failFieldAccess.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
//    DynamicTest test = DynamicTest.dynamicTest("isNotTypeSafe", () -> assertFalse(isTypeSafe));
    assertEquals(tests.size(), 1);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class C:ERROR");

    assertTrue(inOrder.get(6) instanceof DynamicTest);
    assertEquals(inOrder.size(), 12);
  }

  @Test
  @DisplayName("Method Invocation Test - No Parameter")
  void should_ProveTypeSafe_MethodInvocation_NoParameter() {
    String fileName ="MethodInvocationTest/should_invoke_method.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class should_invoke_method:void");
    assertTrue(inOrder.get(6) instanceof DynamicTest);
    assertEquals(inOrder.size(), 31);
  }

  @Test
  @DisplayName("Method Invocation Test - One Parameter")
  void should_ProveTypeSafe_MethodInvocation_OneParameter() {
    String fileName ="MethodInvocationTest/should_invoke_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);
    assertEquals(test1st.getDisplayName(), "class should_invoke_parameter:void");
    assertTrue(inOrder.get(6) instanceof DynamicTest);
    assertEquals(inOrder.size(), 37);

  }

  @Test
  @DisplayName("Method Invocation without Parameter")
  void should_invoke_method_no_parameter() {
    String filename = "MethodInvocationTest/should_invoke_method.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

//    Iterator<DynamicNode> iter = create

    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add(test);
    assertEquals(tests.size(), 2);

    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    assertTrue(inOrder.get(6) instanceof DynamicTest);
  }

  @Test
  @DisplayName("Method Invocation without Parameter")
  void should_invoke_method_with_parameter() {
    String filename = "MethodInvocationTest/should_invoke_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(37, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    // check the block container
    DynamicNode node;

    for (int i = 0; i < 4; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertTrue(Boolean.parseBoolean(node.getDisplayName()));

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(0) = int", node.getDisplayName());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check if tests passed
    node = iterator.next();
    assertFalse(node instanceof DynamicTest);
//    test = (DynamicTest) node;
//    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertFalse(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertFalse(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check if tests passed
    node = iterator.next();
    assertFalse(node instanceof DynamicTest);
//    test = (DynamicTest) node;
//    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertFalse(node instanceof DynamicTest);
//    test = (DynamicTest) node;
//    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertFalse(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());


    for (int i = 0; i < 2; i++) {
      node = iterator.next();
      assertFalse(node instanceof DynamicContainer);
    }
  }

//  @Test
//  @DisplayName("If state With Parameter")
//  void if_negative_cases() {
//    String filename = "ifStatement/should_proveIfStatement_withparameter.java";
//    List<DynamicNode> tests = new ArrayList<>();
//    boolean isTypeSafe = getTypeChecker(filename, tests);
//    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
//    tests.add((DynamicNode)test);
//    assertEquals(tests.size(), 2);
//
//    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
//
//    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
//    Assertions.assertTrue(test1st instanceof DynamicContainer);
//    assertEquals(test1st.getDisplayName(), "class ifstatement_original:void");
//
//    assertTrue(inOrder.get(6) instanceof DynamicTest);
//    DynamicTest test6th = (DynamicTest) inOrder.get(6);
//    Assertions.assertDoesNotThrow(test6th.getExecutable());
//    Assertions.assertTrue(test6th instanceof DynamicTest);
//
//    assertEquals(inOrder.size(), 8);
//  }

  @Test
  @DisplayName("Compatible - Int Variable Declaration")
  void expression_no_parameter() {
    String filename = "typeChecker/should_proveTypeSafe_when_givenVariableDeclrationsWithCompatibleInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(38, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    // check the block container
    DynamicNode node;

    for (int i = 0; i < 4; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(10) = int", node.getDisplayName());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(null) = nullType", node.getDisplayName());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check the container
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(false) = boolean", node.getDisplayName());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());


    for (int i = 0; i < 3; i++) {
      node = iterator.next();
      assertFalse(node instanceof DynamicContainer);
    }
  }

  @Test
  @DisplayName("Bad - Int Variable Declaration")
  void bad_int_variable_declaration() {
    String filename = "typeChecker/should_NotProveTypeSafe_when_givenBadInits.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertFalse(isTypeSafe);
    List<DynamicNode> inOrder = buildListOfDynamicNodes(tests);
    DynamicContainer test1st = (DynamicContainer) inOrder.get(1);
    Assertions.assertTrue(test1st instanceof DynamicContainer);

    assertEquals(test1st.getDisplayName(), "class C:ERROR");
    assertTrue(inOrder.get(6) instanceof DynamicTest);
    assertEquals(inOrder.size(), 32);
  }

  @Test
  @DisplayName("If Statement - With_Parameter")
  void IfStatement_With_Parameter() {
    String filename = "ifStatement/should_proveIfStatement_withparameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(8, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    // check the block container
    DynamicNode node;
    for (int i = 0; i < 4; i++) {
//      node = iterator.next();
//      boolean info = node instanceof DynamicContainer;
//      assertTrue(info);
//      System.out.println(info);
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("true", node.getDisplayName());

    // check if tests passed

    for (int i = 0; i < 3; i ++) {
      node = iterator.next();
      assertTrue( node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
      Assertions.assertEquals("void = void", node.getDisplayName());
    }

    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Not Typesafe infix Statement")
  void should_fail_infix_statement() {
    String filename = "infixExpression_int/should_notProve_infix_type.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertFalse(isTypeSafe);
  }

  @Test
  @DisplayName("Not Typesafe MethodInvoke")
  void should_fail_invoke() {
    String filename = "MethodInvocationTest/should_not_invoke.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertFalse(isTypeSafe);
  }

  @Test
  @DisplayName("Not Typesafe If Statement")
  void should_fail_if_statement() {
    String filename = "ifStatement/should_notproveIfStatement.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertFalse(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(20, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    // check the block container
    DynamicNode node;
    node = iterator.next();

    for (int i = 0; i < 4; i++) {
//      node = iterator.next();
//      boolean info = node instanceof DynamicContainer;
//      assertTrue(info);
//      System.out.println(info);
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(x) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(7) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue( node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(3) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(4) = int", node.getDisplayName());


    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    Assertions.assertEquals("void,ERROR = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    Assertions.assertEquals("ERROR = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    Assertions.assertThrows(AssertionFailedError.class, test.getExecutable());
    Assertions.assertEquals("ERROR = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    Assertions.assertThrows(AssertionFailedError.class, test.getExecutable());
    Assertions.assertEquals("ERROR = void", node.getDisplayName());


    assertFalse(iterator.hasNext());



  }

  @Test
  @DisplayName("While Statement - Without_Parameter")
  void WhileStatement_Without_Parameter() {
    String filename = "whileStatement/should_proveWhileStatement_withoutParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(22, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    // check the block container
//    boolean info = node instanceof DynamicContainer;
//    assertTrue(info);
//    System.out.println(info);

    DynamicNode node;
    for (int i = 0; i < 6; i++) {
//      node = iterator.next();
//      boolean info = node instanceof DynamicContainer;
//      assertTrue(info);
//      System.out.println(info);
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }


    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(x) = int", node.getDisplayName());

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    // check if tests passed
    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(false) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(x) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(2) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void,void = void", node.getDisplayName());

    for (int i = 0; i < 3; i++) {
      node = iterator.next();
      assertTrue( node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
      Assertions.assertEquals("void = void", node.getDisplayName());
    }

    assertFalse(iterator.hasNext());

  }

  @Test
  @DisplayName("Not Typesafe While Statement")
  void should_fail_while_statement() {
    String filename = "other/should_NotProveWhileStatement.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertFalse(isTypeSafe);
  }


  @Test
  @DisplayName("Infix Bool - Without_Parameter")
  void Infix_Bool_Without_Parameter() {
    String filename = "InfixExpression_boolean/should_proveTypeSafe_infix_NoParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(8, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 4; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    // check if tests passed
    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    for (int i = 0; i < 3; i ++) {
      node = iterator.next();
      assertTrue( node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
      Assertions.assertEquals("void = void", node.getDisplayName());
    }


    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Infix Int - Parameter")
  void Infix_Int_Parameter() {
    String filename = "infixExpression_int/should_proveTypeSafe_infix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(21, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 6; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(a) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(c) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(2) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(a) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void,void = void", node.getDisplayName());

    for (int i = 0; i < 3; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
    }

    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Prefix - Parameter")
  void Prefix_Parameter() {
    String filename = "other/prefixExpression/should_proveTypeSafe_prefix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(14, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 7; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(i) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());

    for (int i = 0; i < 4; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
    }

    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Infix Number + Boolean - Parameter")
  void Infix_Int_Number_Boolean() {
    String filename = "InfixExpression_boolean/should__proveTypeSafe_infix.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(15, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 7; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(0) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(1) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());

    for (int i = 0; i < 4; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
    }

    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Infix both bool")
  void Infix_both_Boolean() {
    String filename = "InfixExpression_boolean/should_proveTypeSafe_infix_both_boolean.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(15, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 7; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(true) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(false) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void = void", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("void = void", node.getDisplayName());

    assertFalse(iterator.hasNext());

  }

  @Test
  @DisplayName("Prefix Boolean")
  void prefix_boolean() {
    String filename = "other/prefixExpression/should_proveTypeSafe_prefix_returnBoolean.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(12, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 6; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(false) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(void) = void", node.getDisplayName());


    for (int i = 0; i < 4; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicTest);
      test = (DynamicTest) node;
      assertDoesNotThrow(test.getExecutable());
    }

    assertFalse(iterator.hasNext());
  }


  @Test
  @DisplayName("Expression Statement - everything")
  void expression_statement_everything() {
    String filename = "expressionStatement/should_proveTypeSafe_expression_addition.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(filename, tests);
    assertTrue(isTypeSafe);

    List<DynamicNode> dynamicNodes = buildListOfDynamicNodes(tests);
    Assertions.assertEquals(35, dynamicNodes.size());

    Iterator<DynamicNode> iterator = dynamicNodes.iterator();

    DynamicNode node;
    for (int i = 0; i < 6; i++) {
      node = iterator.next();
      assertTrue(node instanceof DynamicContainer);
    }

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    DynamicTest test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(y) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(3) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(i) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(5) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(x) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(y) = int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("int := int", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(good) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicContainer);

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("E(true) = boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue( node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());
    Assertions.assertEquals("boolean := boolean", node.getDisplayName());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    node = iterator.next();
    assertTrue(node instanceof DynamicTest);
    test = (DynamicTest) node;
    assertDoesNotThrow(test.getExecutable());

    assertFalse(iterator.hasNext());
  }

}
