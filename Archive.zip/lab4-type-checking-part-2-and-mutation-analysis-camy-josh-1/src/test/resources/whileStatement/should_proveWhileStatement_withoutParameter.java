public class whilestatement_original {
    public int name() {
      int x;
      while (false){
        return x = 2;
      }
    }
}