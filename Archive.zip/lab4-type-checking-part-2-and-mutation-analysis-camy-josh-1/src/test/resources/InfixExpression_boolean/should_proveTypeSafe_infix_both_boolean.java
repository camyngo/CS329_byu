public class D {
    public boolean infix_info() {
        return true == false;
    }
}