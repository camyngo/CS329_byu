public class D {
    public int infix_info() {
        return 0 == 1;
    }
}