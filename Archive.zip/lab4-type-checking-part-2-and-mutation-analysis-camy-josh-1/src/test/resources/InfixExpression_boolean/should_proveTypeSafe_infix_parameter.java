package infixExpression_int

public class C {
    public int name(int c) {
        c = 2;
        c + 2 < 10;
        return c;
    }
}