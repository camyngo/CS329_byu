package infixExpression_int

public class C {
    public int name() {
        int a = 1 + 2;
        return a;
    }
}