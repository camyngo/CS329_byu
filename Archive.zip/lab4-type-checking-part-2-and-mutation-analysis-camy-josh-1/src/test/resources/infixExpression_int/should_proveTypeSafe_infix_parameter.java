package infixExpression_int

public class C {
    public int name(int c) {
        int a = c + 2;
        return a;
    }
}