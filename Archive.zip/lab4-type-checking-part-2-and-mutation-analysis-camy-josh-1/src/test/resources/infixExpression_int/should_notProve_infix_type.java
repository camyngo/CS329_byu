public class C {
    public int name() {
        int index = 1 * 2;
        boolean a = index == 3;
        boolean c = true;
        boolean d = index;
        int e = c - 1;
        return a & c & d;
    }
}