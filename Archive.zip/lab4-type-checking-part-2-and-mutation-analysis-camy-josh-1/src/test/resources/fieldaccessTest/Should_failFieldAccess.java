public class C {
  int field;
  int fieldAcessTest(int num) {
    return field;
  }
}
