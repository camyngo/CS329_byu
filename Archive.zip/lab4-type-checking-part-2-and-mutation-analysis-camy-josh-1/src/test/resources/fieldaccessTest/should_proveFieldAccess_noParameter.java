public class C {
  int num;
  int fieldAcessTest() {
    int field;
    this.num = field + 2;
    return this.num;
  }
}
