public class C {
  int num;
  int fieldAcessTest(int b) {
    b = 2;
    this.num = 33 + b;
    return this.num;
  }
}