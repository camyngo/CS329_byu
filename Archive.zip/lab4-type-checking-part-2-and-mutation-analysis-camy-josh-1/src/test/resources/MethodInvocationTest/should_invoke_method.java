public class should_invoke_method {
    public int invoke () {
        int g = num();
        g = 0;
        return g;
    }

    public int num (){
        return 5;
    }
}