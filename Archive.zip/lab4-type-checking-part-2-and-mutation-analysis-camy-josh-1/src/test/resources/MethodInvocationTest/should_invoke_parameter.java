public class should_invoke_parameter {
    public int invoke () {
        int g = num(3);
        int d = 0;
        d = g;
        return d;
    }

    public int num(int a){
        return a;
    }
}