public class whilestatement_original {
    public int name() {
      int x;
      while (3+4){
        return x = 2;
      }
    }
}