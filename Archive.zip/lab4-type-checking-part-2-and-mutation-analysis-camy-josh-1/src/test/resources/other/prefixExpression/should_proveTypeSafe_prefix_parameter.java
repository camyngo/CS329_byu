package prefixExpression;

public class C {
    public boolean m(boolean i) {
        return !i;
    }
}