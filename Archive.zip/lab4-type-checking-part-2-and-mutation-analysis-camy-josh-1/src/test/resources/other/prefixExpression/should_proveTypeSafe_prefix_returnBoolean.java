package prefixExpression;

public class C {
    public boolean m() {
        return false;
    }
}