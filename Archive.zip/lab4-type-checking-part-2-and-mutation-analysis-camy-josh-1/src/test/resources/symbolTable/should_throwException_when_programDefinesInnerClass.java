package symbolTable;

public class should_throwAssertion_when_programDefinesInnerClass0 {
  public class should_throwAssertion_when_programDefinesInnerClass1 {

  }
}
