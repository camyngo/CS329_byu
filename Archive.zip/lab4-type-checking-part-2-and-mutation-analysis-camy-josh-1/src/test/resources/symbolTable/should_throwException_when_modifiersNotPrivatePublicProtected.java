package symbolTabel;

public class should_throwAssertion_when_modifiersNotPrivatePublicProtected {
  private static int i;
  public final static Integer x = null;
}
