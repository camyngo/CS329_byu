package symbolTable;

public class should_throwAssertion_when_programDefinesTwoClasses0 {
  
}

public class should_throwAssertion_when_programDefinesTwoClasses1 {
  
}
