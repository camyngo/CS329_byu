package symbolTable;

public class should_throwAssertion_when_multipleVariablesInFragments {
  int f, g, h;
}
