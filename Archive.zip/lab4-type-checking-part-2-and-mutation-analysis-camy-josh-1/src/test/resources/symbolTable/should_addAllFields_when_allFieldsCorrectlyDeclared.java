package symbolTable;

public class should_addAllFields_when_allFieldsCorrectlyDeclared {
  int i;
  public int j;
  private should_addAllFields_when_allFieldsCorrectlyDeclared k;
  protected Integer m;
}
