package symbolTable;

public class should_throwAssertion_when_typeIsNotSimpleOrPrimitive {
  java.lang.Integer i;
}
