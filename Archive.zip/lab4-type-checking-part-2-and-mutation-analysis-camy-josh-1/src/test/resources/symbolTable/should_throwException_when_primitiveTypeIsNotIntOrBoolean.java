package symbolTable;

public class should_throwAssertion_when_primitiveTypeIsNotIntOrBoolean {
  long i;
}
