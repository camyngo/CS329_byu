package symbolTable;

import java.util.List;

public class should_throwAssertion_when_programHasImports {
  List list;  
}
