public class should_createParameterTypeMaps_when_methodsExist {
  void m(int i, Integer j) {
  }

  int n() {
    return 10;    
  }
}
