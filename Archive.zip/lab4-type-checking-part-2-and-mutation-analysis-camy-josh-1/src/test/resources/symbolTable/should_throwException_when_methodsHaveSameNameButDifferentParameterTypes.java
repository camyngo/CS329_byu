public class should_throwAssertion_when_methodsHaveSameNameButDifferentParameterTypes {
  void m(int i) {

  }
  void m(Integer i) {
    
  }
}
