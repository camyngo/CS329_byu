package typeChecker;

public class C {
  void m() {

  }
}
