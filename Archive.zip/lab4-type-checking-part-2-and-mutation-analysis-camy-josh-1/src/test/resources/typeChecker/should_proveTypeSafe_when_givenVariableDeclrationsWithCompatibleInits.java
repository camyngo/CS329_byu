package typeChecker;

public class C {
  int m(int i) {
    int j = 10;
    Integer k = null;
    C c = null;
    C d = c;
    boolean e = false;
  }
}
