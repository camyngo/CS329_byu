public class C {
  int m(int i) {
    int j;
    Integer k;
    C c;
  }
}
