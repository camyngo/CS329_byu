package typeChecker;

public class C {
  int m(int i) {
    int j = null;
    Integer k = 10;
    C c = false;
    boolean d = 10;
  }
}
