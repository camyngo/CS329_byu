package typeChecker;

public class C {
  public int m(int i) {
    
  }  
}
