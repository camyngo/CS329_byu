package expressionStatement;

public class C {
    public void m() {
        int i = 5;
    }
}