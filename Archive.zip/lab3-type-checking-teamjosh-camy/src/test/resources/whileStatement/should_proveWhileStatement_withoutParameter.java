public class whilestatement_original {
    public int name() {
      int x;
      while (true){
        return x = 2;
      }
    }
}