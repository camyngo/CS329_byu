package infixExpression_int

public class C {
    public int name() {
        int a = 2;
        if( a == 2) return 3;
    }
}