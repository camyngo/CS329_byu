public class ifstatement_notFolded_original {
    public int name() {
        private int x = 7;
        if (3+4){
          return x = 2;
        }
    }
}