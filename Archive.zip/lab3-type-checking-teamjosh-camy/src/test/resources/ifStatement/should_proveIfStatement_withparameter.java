public class ifstatement_original {
    public int name(int x) {
        if (true) {
            a
        }
        else {
          return 3 + 4;
        }
    }
}