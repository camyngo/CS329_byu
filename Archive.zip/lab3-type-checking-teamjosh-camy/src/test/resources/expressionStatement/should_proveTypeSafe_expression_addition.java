package expressionStatement;

public class C {
    public void m() {
        int y = 3;
        int i = 5;
        int x = y + i;
    }
}