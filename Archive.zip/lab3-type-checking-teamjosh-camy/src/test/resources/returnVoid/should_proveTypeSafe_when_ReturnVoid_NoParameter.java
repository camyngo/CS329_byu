package returnVoid;

public class C {
  public void m() {
  }
}