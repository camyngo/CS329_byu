package returnVoid;

public class C {
  public void m(int i) {

  }
}