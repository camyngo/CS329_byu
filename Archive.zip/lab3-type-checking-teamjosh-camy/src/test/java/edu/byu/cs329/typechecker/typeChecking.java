package edu.byu.cs329.typechecker;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.eclipse.jdt.core.dom.ASTNode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;


public class typeChecking {

  private boolean getTypeChecker(final String fileName, List<DynamicNode> tests) {
    ASTNode compilationUnit = Utils.getAstNodeFor(this, fileName);
    SymbolTableBuilder symbolTableBuilder = new SymbolTableBuilder();
    ISymbolTable symbolTable = symbolTableBuilder.getSymbolTable(compilationUnit);
    TypeCheckBuilder typeCheckerBuilder = new TypeCheckBuilder();
    return typeCheckerBuilder.getTypeChecker(symbolTable, compilationUnit, tests);
  }

  @TestFactory
  @DisplayName("Return Void - With a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_returnVoid_withParameter() {
    String fileName = "returnVoid/should_proveTypeSafe_when_ReturnVoid.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Return Void - Without a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_returnVoid_withoutParameter() {
    String fileName = "returnVoid/should_proveTypeSafe_when_ReturnVoid_NoParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Prefix Boolean - With a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_prefixBoolean_withParameter() {
    String fileName = "prefixExpression/should_proveTypeSafe_prefix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Prefix Boolean - withoout a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_prefixBoolean_withoutParameter() {
    String fileName = "prefixExpression/should_proveTypeSafe_prefix_returnBoolean.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix Int - Without a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_infix_withoutParameter() {
    String fileName = "infixExpression_int/should_proveTypeSafe_infix_NoParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix Int - With a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_infix_withParameter() {
    String fileName = "infixExpression_int/should_proveTypeSafe_infix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix BOOLEAN- Without a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_infixBOOLEAN_withoutParameter() {
    String fileName = "InfixExpression_boolean/should_proveTypeSafe_infix_NoParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Infix BOOLEAN - With a Parameter")
  Stream<DynamicNode> should_proveTypeSafe_when_infixBOOLEAN_withParameter() {
    String fileName = "InfixExpression_boolean/should_proveTypeSafe_infix_parameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Expression Void - Addition")
  Stream<DynamicNode> should_proveTypeSafe_expression_addition() {
    String fileName = "expressionStatement/should_proveTypeSafe_expression_addition.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }

  @TestFactory
  @DisplayName("Expression Void - Addition")
  Stream<DynamicNode> should_proveTypeSafe_expression_NOParameter() {
    String fileName = "expressionStatement/should_proveTypeSafe_expression_NoParameter.java";
    List<DynamicNode> tests = new ArrayList<>();
    boolean isTypeSafe = getTypeChecker(fileName, tests);
    DynamicTest test = DynamicTest.dynamicTest("isTypeSafe", () -> assertTrue(isTypeSafe));
    tests.add((DynamicNode)test);
    return tests.stream();
  }
  

}
