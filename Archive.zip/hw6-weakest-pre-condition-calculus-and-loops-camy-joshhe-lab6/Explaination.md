Problem 1 is problem1.jpg
Problem 2 is problem2.jpg
Problem 3 is problem3.jpg
Problem 4.is problem4.jpg

Thank you for this semester! :)