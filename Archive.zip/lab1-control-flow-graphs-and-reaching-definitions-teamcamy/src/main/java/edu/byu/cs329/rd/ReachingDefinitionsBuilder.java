package edu.byu.cs329.rd;

import edu.byu.cs329.cfg.ControlFlowGraph;
import edu.byu.cs329.rd.ReachingDefinitions.Definition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class ReachingDefinitionsBuilder {
  private List<ReachingDefinitions> rdList = null;
  private Map<Statement, Set<Definition>> entrySetMap = null;

  /**
   * Computes the reaching definitions for each control flow graph.
   * 
   * @param cfgList the list of control flow graphs.
   * @return the coresponding reaching definitions for each graph.
   */
  public List<ReachingDefinitions> build(List<ControlFlowGraph> cfgList) {
    rdList = new ArrayList<>();
    for (ControlFlowGraph cfg : cfgList) {
      ReachingDefinitions rd = computeReachingDefinitions(cfg);
      rdList.add(rd);
    }
    return rdList;
  }

  private ReachingDefinitions computeReachingDefinitions(ControlFlowGraph cfg) {
    // gen sets
    Set<Definition> parameterDefinitions = createParameterDefinitions(cfg.getMethodDeclaration());
    entrySetMap = new HashMap<>();
    Map<Statement, Set<Definition>> exitSetMap = new HashMap<>();

    Stack<Statement> worklist = new Stack<>();

    Statement start = cfg.getStart();
    worklist.push(start);
    entrySetMap.put(start, parameterDefinitions);


    // loops until we done with working w the statements
    while (!worklist.isEmpty()) {
      Set<Definition> exitSet = new HashSet<>();

      Statement current = worklist.pop();
      SimpleName name = getName(current);
      Definition definition = null;

      // get the entry set, if empty, create a new entry map
      if (entrySetMap.get(current) == null) {
        Set<Definition> temp = new HashSet<>();
        entrySetMap.put(current, temp);
      }
      Set<Definition> entrySet = entrySetMap.get(current);

      if (name != null) {
//        definition = createDefinition(name, current);
        // union over predecessors
        Set<Statement> allPredecessor = cfg.getPreds(current);
        if(allPredecessor != null){
          for (Statement a : allPredecessor) {
            Set<Definition> definitions = exitSetMap.get(a);
            entrySet.addAll(definitions);
          }
          // ONLY PUT A NEW ENTRY SET IF EMPTY
          entrySetMap.putIfAbsent(current, entrySet);
          if (exitSetMap.get(current) == null ){
            // empty set of definitions
            Set<Definition> temp = new HashSet<>();
            exitSetMap.put(current, temp);
          }
          // should be empty temp

          Set<Definition> temp = new HashSet<>(exitSetMap.get(current));
          boolean changed = false;
          exitSet.clear();
          exitSet.addAll(entrySet);
          exitSetMap.put(current, temp);

          // kill sets
          exitSet.removeIf(n -> n.name.getIdentifier().equals(name.getIdentifier()));

          definition = createDefinition(name, current);
          exitSet.add(definition);
          exitSetMap.put(current, exitSet);

          Set<Statement> allSuccessors = cfg.getSuccs(current);
          // check changed, exitSetMap
          if (!temp.equals(exitSetMap.get(current))) {
            changed = true;
          }
          if (changed) {
            for (Statement stmt : allSuccessors) {
              worklist.push(stmt);
            }
          }
        }
      }

    }
    return new ReachingDefinitions() {
      final Map<Statement, Set<Definition>> reachingDefinitions = 
          Collections.unmodifiableMap(entrySetMap);

      @Override 
      public Set<Definition> getReachingDefinitions(final Statement s) {
        Set<Definition> returnValue = null;
        if (reachingDefinitions.containsKey(s)) {
          returnValue = reachingDefinitions.get(s);
        }
        return returnValue;
      }
    };
  }

  /**
   * checking if two sets are equal.
   *
   * @param set1 first set
   * @param set2 second set
   * @return whether two sets are equal to each other
   */
  public static boolean equals(Set<?> set1, Set<?> set2) {

        if(set1 == null || set2 ==null){
            return false;
        }

        if(set1.size() != set2.size()){
            return false;
        }

        return set1.containsAll(set2);
    }

  private SimpleName getName (Statement statement) {
        SimpleName name = null;
        if (statement instanceof ExpressionStatement) {
          Expression expressionStatement = ((ExpressionStatement) statement).getExpression();
            if (expressionStatement instanceof Assignment) {
              // all of the simple name is on the left hand side
                name = (SimpleName) ((Assignment) expressionStatement).getLeftHandSide();
            }
        }
        else if (statement instanceof VariableDeclarationStatement) {
            VariableDeclarationStatement variableDeclarationStatement = (VariableDeclarationStatement)  statement;
            if (!variableDeclarationStatement.fragments().isEmpty()) {
                name = ((VariableDeclaration) variableDeclarationStatement.fragments().get(0)).getName();
            }
        }
        return name;
  }


  private Set<Definition> createParameterDefinitions(MethodDeclaration methodDeclaration) {
    List<VariableDeclaration> parameterList = 
        getParameterList(methodDeclaration.parameters());
    Set<Definition> set = new HashSet<Definition>();

    for (VariableDeclaration parameter : parameterList) {
      Definition definition = createDefinition(parameter.getName(), null);
      set.add(definition);  
    }

    return set;
  }

  private Definition createDefinition(SimpleName name, Statement statement) {
    Definition definition = new Definition();
    definition.name = name;
    definition.statement = statement;
    return definition;
  }

  private List<VariableDeclaration> getParameterList(Object list) {
    @SuppressWarnings("unchecked")
    List<VariableDeclaration> statementList = (List<VariableDeclaration>)(list);
    return statementList;
  }
}
