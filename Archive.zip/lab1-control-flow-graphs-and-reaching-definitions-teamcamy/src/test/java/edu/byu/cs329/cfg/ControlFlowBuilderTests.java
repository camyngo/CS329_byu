package edu.byu.cs329.cfg;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.byu.cs329.rd.MockUtils;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Statement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("Tests for ControlFlowBuilder")
public class ControlFlowBuilderTests {
  ControlFlowGraphBuilder unitUnderTest = null;
  ControlFlowGraph controlFlowGraph = null;
  StatementTracker statementTracker = null;

  @BeforeEach
  void beforeEach() {
    unitUnderTest = new ControlFlowGraphBuilder();
  }

  void init(String fileName) {
    ASTNode node = ParseUtils.getASTNodeFor(this, fileName);
    List<ControlFlowGraph> cfgList = unitUnderTest.build(node);
    assertEquals(1, cfgList.size());
    controlFlowGraph = cfgList.get(0);
    statementTracker = new StatementTracker(node);
  }

  @Test
  @Tag("MethodDeclaration")
  @DisplayName("Should set start and end same when empty method declaration")
  void should_SetStartAndEndSame_when_EmptyMethodDeclaration() {
    String fileName = "cfgInputs/should_SetStartAndEndSame_when_EmptyMethodDeclaration.java";
    init(fileName);
    assertAll("Method declaration with empty block",
        () -> assertNotNull(controlFlowGraph.getMethodDeclaration()),
        () -> assertEquals(controlFlowGraph.getStart(), controlFlowGraph.getEnd())
    );
  }

  @Test
  @Tag("MethodDeclaration")
  @DisplayName("Should set start to first statement and end different when non-empty method declaration")
  void should_SetStartToFirstStatementAndEndDifferent_when_NonEmptyMethodDeclaration() {
    String fileName = "cfgInputs/should_SetStartToFirstStatementAndEndDifferent_when_NonEmptyMethodDeclaration.java";
    init(fileName);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Statement variableDeclStatement = statementTracker.getVariableDeclarationStatement(0);
    assertAll("Method declaration with non-empty block",
        () -> assertNotNull(controlFlowGraph.getMethodDeclaration()), 
        () -> assertNotEquals(start, end),
        () -> assertTrue(start == variableDeclStatement),
        () -> assertTrue(hasEdge(variableDeclStatement, end))
    );    
  }

  @Test
  @Tag("Block")
  @DisplayName("Should link all when block has no return")
  void should_LinkAll_when_BlockHasNoReturn() {
    String fileName = "cfgInputs/should_LinkAll_when_BlockHasNoReturn.java";
    init(fileName);
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement expressionStatement = statementTracker.getExpressionStatement(0);
    assertTrue(hasEdge(variableDeclaration, expressionStatement));
  }

  @Test
  @Tag("Block")
  @DisplayName("Should link to return when block has return") 
  void should_LinkToReturn_when_BlockHasReturn() {
    String fileName = "cfgInputs/should_LinkToReturn_when_BlockHasReturn.java";
    init(fileName);
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement expressionStatement = statementTracker.getExpressionStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);
    // reaching definition right here give back a control flow graph
    // passing to reaching definition build
    List<ControlFlowGraph> controlFlowGraph = new ArrayList<ControlFlowGraph>();
    assertAll(
        () -> assertTrue(hasEdge(variableDeclaration, returnStatement)),
        () -> assertFalse(hasEdge(returnStatement, expressionStatement))
    );
  }

  @Test
  @Tag("ReturnStatement")
  @DisplayName("ReturnStatement Test with a return statement")
  void ReturnStatement() {
    String fileName = "cfgInputs/ReturnStatement.java";
    init(fileName);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);
    assertAll(
        () -> assertTrue(hasEdge(variableDeclaration, returnStatement)),
        () -> assertTrue(hasEdge(returnStatement,end))
    );
  }

  @Test
  @Tag("ReturnStatement")
  @DisplayName("Null return statement")
  void ReturnStatement2() {
    String fileName = "cfgInputs/ReturnStatement2.java";
    init(fileName);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);
    assertAll(
        () -> assertTrue(hasEdge(variableDeclaration, returnStatement)),
        () -> assertTrue(hasEdge(returnStatement,end))
    );
  }


  @Test
  @Tag("IfStatement")
  @DisplayName("IfStatement Test")
  void IfStatement() {
    String fileName = "cfgInputs/IfStatement.java";
    init(fileName);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();

    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement ifstatement = statementTracker.getIfStatement(0);
    Statement thenExpression = statementTracker.getExpressionStatement(0);
    Statement elseExpression = statementTracker.getExpressionStatement(1);
    Statement returnStatement = statementTracker.getReturnStatement(0);
    assertAll(
        () -> assertTrue(hasEdge(variableDeclaration, ifstatement)),
        () -> assertTrue(hasEdge(ifstatement,thenExpression)),
        () -> assertTrue(hasEdge(ifstatement,elseExpression)),
        () -> assertTrue(hasEdge(thenExpression,returnStatement)),
        () -> assertTrue(hasEdge(elseExpression,returnStatement)),
        () -> assertTrue(hasEdge(returnStatement,end))
    );
  }


  @Test
  @Tag("WhileStatement")
  @DisplayName("WhileStatement Test")
  void WhileStatement() {
    String fileName = "cfgInputs/WhileStatement.java";
    init(fileName);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement expressionStatement = statementTracker.getExpressionStatement(0);
    Statement whileStatement = statementTracker.getWhileStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);

    // checking existence of edges between statements
    assertAll(
            () -> assertTrue(hasEdge(variableDeclaration, whileStatement)),
            () -> assertTrue(hasEdge(whileStatement, expressionStatement)),
            () -> assertTrue(hasEdge(whileStatement, returnStatement)),
            () -> assertTrue(hasEdge(returnStatement,end))
    );
  }

  @Test
  @Tag("WhileStatement")
  @DisplayName("WhileStatement Test with return statement is the only statement and no expression")
  void WhileStatement2() {
    String fileName = "cfgInputs/WileStatement2.java";
    init(fileName);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Statement whileStatement = statementTracker.getWhileStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);

    // checking existence of edges between statements
    assertAll(
        () -> assertEquals(start, whileStatement),
        () -> assertTrue(hasEdge(whileStatement, returnStatement)),
        () -> assertTrue(hasEdge(returnStatement,end))
    );
  }

  @Test
  @Tag("WhileStatement")
  @DisplayName("WhileStatement Test with no while statement")
  void WhileStatement3() {
    String fileName = "cfgInputs/WhileStatment3.java";
    init(fileName);
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement expressionStatement = statementTracker.getExpressionStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);
    assertAll(
        () -> assertTrue(hasEdge(variableDeclaration, expressionStatement)),
        () -> assertTrue(hasEdge(expressionStatement, returnStatement))
    );
  }



  private boolean hasEdge(Statement source, Statement dest) {
    Set<Statement> successors = controlFlowGraph.getSuccs(source);
    Set<Statement> predecessors = controlFlowGraph.getPreds(dest);
    return successors != null && successors.contains(dest) 
        && predecessors != null && predecessors.contains(source);
  }
}
