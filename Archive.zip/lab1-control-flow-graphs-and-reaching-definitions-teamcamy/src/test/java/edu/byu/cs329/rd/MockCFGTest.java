package edu.byu.cs329.rd;

import edu.byu.cs329.cfg.ControlFlowGraph;
import org.eclipse.jdt.core.dom.*;
import org.junit.jupiter.api.DisplayName;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.mockito.Mockito.*;

@DisplayName("How to mock a CFG")
public class MockCFGTest {

  public static ControlFlowGraph createMCFG() {
    ControlFlowGraph cfg = mock(ControlFlowGraph.class);

    MethodDeclaration f = mock(MethodDeclaration.class);
    SimpleName fname = mock(SimpleName.class);

    when(fname.getIdentifier()).thenReturn("f");

    List<SingleVariableDeclaration> fParemas = new ArrayList<SingleVariableDeclaration>();
    SingleVariableDeclaration a = mockParams("a", PrimitiveType.INT);
    SingleVariableDeclaration b = mockParams("b", PrimitiveType.INT);
    fParemas.add(a);
    fParemas.add(b);
    when(f.parameters()).thenReturn(fParemas);

    Block b0 = mock(Block.class);
    List<Statement> statements = new ArrayList<Statement>();
    when(b0.statements()).thenReturn(statements);
    when(f.getBody()).thenReturn(b0);

    // list of statement
    VariableDeclarationStatement s1 = mock(VariableDeclarationStatement.class);
    statements.add(s1);

    ExpressionStatement s2= mock(ExpressionStatement.class);
    statements.add(s2);

    IfStatement s3 = mock(IfStatement.class);
    statements.add(s3);

    WhileStatement s4 = mock(WhileStatement.class);
    statements.add(s4);

    ExpressionStatement s5= mock(ExpressionStatement.class);
    statements.add(s5);

    ReturnStatement r8 = mock(ReturnStatement.class);
    statements.add(r8);


    when(b0.statements()).thenReturn(statements);
    when(f.getBody()).thenReturn(b0);

    when(cfg.getStart()).thenReturn(s1);
    when(cfg.getEnd()).thenReturn(b0);
    when(cfg.getMethodDeclaration()).thenReturn(f);

  // verify the end of methods
    verify(cfg, times(1)).getStart();
    verify(cfg, never()).getMethodDeclaration();
    verifyNoInteractions(cfg);

    return cfg;
  }

  public static SingleVariableDeclaration mockParams(String name, PrimitiveType.Code type){
      SingleVariableDeclaration params = mock(SingleVariableDeclaration.class);
      SimpleName paramName = mock(SimpleName.class);

      when(paramName.getIdentifier()).thenReturn(name);
      when(params.getName()).thenReturn(paramName);
      PrimitiveType paramsType = mock(PrimitiveType.class);

      when(paramsType.getPrimitiveTypeCode()).thenReturn(type);
      return params;
  }






}
