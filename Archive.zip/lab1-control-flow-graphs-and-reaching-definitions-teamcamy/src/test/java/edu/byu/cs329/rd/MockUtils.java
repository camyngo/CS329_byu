package edu.byu.cs329.rd;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.jdt.core.dom.*;

import edu.byu.cs329.cfg.ControlFlowGraph;

public class MockUtils {
  public static ControlFlowGraph newMockForEmptyMethodWithTwoParameters(String first, String second) {
    ControlFlowGraph cfg = mock(ControlFlowGraph.class);
    Statement statement = mock(Statement.class);
    when(cfg.getStart()).thenReturn(statement);
    MethodDeclaration methodDeclarion = mock(MethodDeclaration.class);
    VariableDeclaration firstParameter = newMockForVariableDeclaration(first);
    VariableDeclaration secondParameter = newMockForVariableDeclaration(second);
    List<VariableDeclaration> parameterList = new ArrayList<VariableDeclaration>();
    parameterList.add(firstParameter);
    parameterList.add(secondParameter);
    when(methodDeclarion.parameters()).thenReturn(parameterList);
    when(cfg.getMethodDeclaration()).thenReturn(methodDeclarion);
    return cfg;
  }

  public static ControlFlowGraph newMockForEmptyMethod() {
    ControlFlowGraph cfg = mock(ControlFlowGraph.class);
    MethodDeclaration methodDeclarion = mock(MethodDeclaration.class);
    when(cfg.getMethodDeclaration()).thenReturn(methodDeclarion);
    return cfg;
  }

  public static VariableDeclaration newMockForVariableDeclaration(String name) {
    VariableDeclaration declaration = mock(VariableDeclaration.class);
    SimpleName simpleName = mock(SimpleName.class);
    when(simpleName.getIdentifier()).thenReturn(name);
    when(declaration.getName()).thenReturn(simpleName);
    return declaration;
  }

  public static ExpressionStatement newExpressionStatement(String name) {
    ExpressionStatement declaration = mock(ExpressionStatement.class);
    SimpleName simpleName = mock(SimpleName.class);
    Assignment assignment = mock(Assignment.class);
    when(declaration.getExpression()).thenReturn(assignment);
    when(assignment.getLeftHandSide()).thenReturn(simpleName);
    when(simpleName.getIdentifier()).thenReturn(name);
    return declaration;
  }

  public static IfStatement newIfStatement(String name) {
    IfStatement declaration = mock(IfStatement.class);
    InfixExpression infixExpression = mock(InfixExpression.class);
    Statement statement = mock(Statement.class);
    SimpleName simpleName = mock(SimpleName.class);

    when(declaration.getExpression()).thenReturn(infixExpression);
    when(infixExpression.getLeftOperand()).thenReturn(simpleName);
    when(simpleName.getIdentifier()).thenReturn(name);
    return declaration;
  }

  public static WhileStatement newWhileStatement(String name) {
    WhileStatement declaration = mock(WhileStatement.class);
    SimpleName simpleName = mock(SimpleName.class);
    when(simpleName.getIdentifier()).thenReturn(name);
    when(declaration.getExpression()).thenReturn(simpleName);
    return declaration;
  }

  public static ReturnStatement newReturnStatement(String name) {
    ReturnStatement declaration = mock(ReturnStatement.class);
    SimpleName simpleName = mock(SimpleName.class);
    when(simpleName.getIdentifier()).thenReturn(name);
    when(declaration.getExpression()).thenReturn(simpleName);
    return declaration;
  }

  public static Set<Statement> makeSet(Statement ... array ){
    Set<Statement> set = new HashSet<>();
    for(Statement s : array) {
      set.add(s);
    }
    return set;
  }


}
