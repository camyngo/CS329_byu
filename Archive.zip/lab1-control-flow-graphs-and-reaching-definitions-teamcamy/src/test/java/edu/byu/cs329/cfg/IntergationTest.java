package edu.byu.cs329.cfg;

import edu.byu.cs329.rd.ReachingDefinitions;
import edu.byu.cs329.rd.ReachingDefinitionsBuilder;
import org.eclipse.jdt.core.dom.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;


import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class IntergationTest {
  ReachingDefinitionsBuilder unitUnderTest = null;
  ControlFlowGraphBuilder CFUnderTest = null;
  ControlFlowGraph controlFlowGraph = null;
  StatementTracker statementTracker = null;
  @BeforeEach
  void beforeEach() {
    unitUnderTest = new ReachingDefinitionsBuilder();
    CFUnderTest = new ControlFlowGraphBuilder();
  }
  void init(String fileName) {
    ASTNode node = ParseUtils.getASTNodeFor(this, fileName);
    List<ControlFlowGraph> cfgList = CFUnderTest.build(node);
    assertEquals(1, cfgList.size());
    controlFlowGraph = cfgList.get(0);
    statementTracker = new StatementTracker(node);
  }

  @Test
  @Tag("Block")
  @DisplayName("Should link to return when block has return")
  void should_LinkToReturn_when_BlockHasReturn() {
    String fileName = "cfgInputs/should_LinkToReturn_when_BlockHasReturn.java";
    init(fileName);
    Statement variableDeclaration = statementTracker.getVariableDeclarationStatement(0);
    Statement expressionStatement = statementTracker.getExpressionStatement(0);
    Statement returnStatement = statementTracker.getReturnStatement(0);
    Statement block = statementTracker.getBlock(0);
    // reaching definition right here give back a control flow graph
    // passing to reaching definition build
    ReachingDefinitions reachingDefinitions = getReachingDefinitions(controlFlowGraph);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Set<ReachingDefinitions.Definition> definitions = reachingDefinitions.getReachingDefinitions(start);
    assertAll(
        () -> assertEquals(controlFlowGraph.getSuccs(returnStatement).size(), 1),
        () -> assertEquals(controlFlowGraph.getPreds(returnStatement).size(), 1)
    );
  }

  private ReachingDefinitions getReachingDefinitions(ControlFlowGraph controlFlowGraph) {
    List<ControlFlowGraph> list = new ArrayList<ControlFlowGraph>();
    list.add(controlFlowGraph);
    List<ReachingDefinitions> reachingDefinitionsList = unitUnderTest.build(list);
    assertEquals(1, reachingDefinitionsList.size());
    return reachingDefinitionsList.get(0);
  }

}
