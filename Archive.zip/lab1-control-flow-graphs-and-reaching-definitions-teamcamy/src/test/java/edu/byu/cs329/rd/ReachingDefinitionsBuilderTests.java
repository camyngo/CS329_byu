package edu.byu.cs329.rd;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.*;

import edu.byu.cs329.cfg.ControlFlowGraphBuilder;
import edu.byu.cs329.cfg.ParseUtils;
import edu.byu.cs329.cfg.StatementTracker;
import org.eclipse.jdt.core.dom.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import edu.byu.cs329.cfg.ControlFlowGraph;
import edu.byu.cs329.rd.ReachingDefinitions.Definition;
import org.mockito.Mock;

@DisplayName("Tests for ReachingDefinitionsBuilder")
public class ReachingDefinitionsBuilderTests {

  ReachingDefinitionsBuilder unitUnderTest = null;
  ControlFlowGraphBuilder CFUnderTest = null;
  ControlFlowGraph controlFlowGraph = null;
  StatementTracker statementTracker = null;

  @BeforeEach
  void beforeEach() {
    unitUnderTest = new ReachingDefinitionsBuilder();
  }

  void init(String fileName) {
    fileName = "rdInput/MockTest.java";
    init(fileName);
    ASTNode node = ParseUtils.getASTNodeFor(this, fileName);
    List<ControlFlowGraph> cfgList = CFUnderTest.build(node);
    assertEquals(1, cfgList.size());
    controlFlowGraph = cfgList.get(0);
    statementTracker = new StatementTracker(node);
  }

  @Test
  @Tag("Parameters Testing")
  @DisplayName("Should have a definition for each parameter at start when the method declaration has parameters.")
  void should_HaveDefinitionForEachParameterAtStart_when_MethodDeclarationHasParameters() {
    ControlFlowGraph controlFlowGraph = MockUtils.newMockForEmptyMethodWithTwoParameters("a", "b");
    Statement statement = controlFlowGraph.getStart();
    Set<Statement> successor = new HashSet<>();
    successor.add(controlFlowGraph.getEnd());
    when(controlFlowGraph.getSuccs(statement)).thenReturn(successor);
    ReachingDefinitions reachingDefinitions = getReachingDefinitions(controlFlowGraph);
    Statement start = controlFlowGraph.getStart();
    Set<Definition> definitions = reachingDefinitions.getReachingDefinitions(start);
    assertEquals(2, definitions.size());
    assertAll("Parameters Defined at Start",
        () -> assertTrue(doesDefine("a", definitions)),
        () -> assertTrue(doesDefine("b", definitions))
    );
  }

  @Test
  @Tag("If-statement")
  @DisplayName(" Testing if-statement can reach return block.")
  void shouldReturn_IfAndElseStatement_definitions() {
    String paramName = "a";
    String varName = "b";

    // Mock Statement in methods
    ControlFlowGraph controlFlowGraph = MockUtils.newMockForEmptyMethodWithTwoParameters(paramName, varName);

    VariableDeclarationStatement s1 = mock(VariableDeclarationStatement.class);
    VariableDeclaration s1Declaration = MockUtils.newMockForVariableDeclaration("x");
    when(s1.fragments()).thenReturn(Collections.singletonList(s1Declaration));

    Statement s2 = MockUtils.newExpressionStatement("x");
    Statement s3 = MockUtils.newIfStatement(paramName);
    // add on s7 for fail case
    Statement s7 = MockUtils.newExpressionStatement("x");
    Statement s8 = MockUtils.newReturnStatement("x");
    Block b0 = mock(Block.class);

    when(controlFlowGraph.getStart()).thenReturn(s1);
    when(controlFlowGraph.getEnd()).thenReturn(b0);
    when(controlFlowGraph.getPreds(s1)).thenReturn(MockUtils.makeSet());
    when(controlFlowGraph.getSuccs(s1)).thenReturn(MockUtils.makeSet(s2));
    when(controlFlowGraph.getPreds(s2)).thenReturn(MockUtils.makeSet(s1));
    when(controlFlowGraph.getSuccs(s2)).thenReturn(MockUtils.makeSet(s3));
    when(controlFlowGraph.getPreds(s3)).thenReturn(MockUtils.makeSet(s2));
    when(controlFlowGraph.getSuccs(s3)).thenReturn(MockUtils.makeSet(s7,s8));

    when(controlFlowGraph.getPreds(s7)).thenReturn(MockUtils.makeSet(s3));
    when(controlFlowGraph.getSuccs(s7)).thenReturn(MockUtils.makeSet(s8));

    when(controlFlowGraph.getPreds(s8)).thenReturn(MockUtils.makeSet(s3,s7));

    when(controlFlowGraph.getSuccs(s8)).thenReturn(MockUtils.makeSet(b0));
    when(controlFlowGraph.getPreds(b0)).thenReturn(MockUtils.makeSet(s8));
    when(controlFlowGraph.getSuccs(b0)).thenReturn(MockUtils.makeSet());

    ReachingDefinitions reachingDefinitions = getReachingDefinitions(controlFlowGraph);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Set<Definition> definitions = reachingDefinitions.getReachingDefinitions(start);
    Set<Definition> definitions2 = reachingDefinitions.getReachingDefinitions(s2);
    Set<Definition> block = reachingDefinitions.getReachingDefinitions(b0);



    assertAll("Parameters Defined at Start",
        () -> assertTrue(doesDefine("a", definitions)),
        () -> assertTrue(doesDefine("b", definitions)),
        () -> assertEquals(start, s1),
        () -> assertEquals(end, b0),
        () -> assertEquals(2, definitions.size()),
        () -> assertEquals(3, definitions2.size())
//        () -> assertEquals(3, block.size())
    );
  }

  @Test
  @Tag("While-loops")
  @DisplayName(" Testing while-loops can reach return block.")
  void shouldReturn_WhileLoops_definitions() {
    String paramName = "a";
    String varName = "b";

    // Mock Statement in methods
    ControlFlowGraph controlFlowGraph = MockUtils.newMockForEmptyMethodWithTwoParameters(paramName, varName);

    VariableDeclarationStatement s1 = mock(VariableDeclarationStatement.class);
    VariableDeclaration s1Declaration = MockUtils.newMockForVariableDeclaration("x");
    when(s1.fragments()).thenReturn(Collections.singletonList(s1Declaration));

    Statement s2 = MockUtils.newExpressionStatement("x");
    Statement s3 = MockUtils.newIfStatement("x");
    Statement s4 = mock(WhileStatement.class);
    Statement s5 = MockUtils.newExpressionStatement("x");
    Statement s8 = MockUtils.newReturnStatement("x");
    Block b0 = mock(Block.class);

    when(controlFlowGraph.getStart()).thenReturn(s1);
    when(controlFlowGraph.getEnd()).thenReturn(b0);
    when(controlFlowGraph.getPreds(s1)).thenReturn(MockUtils.makeSet());
    when(controlFlowGraph.getSuccs(s1)).thenReturn(MockUtils.makeSet(s2));
    when(controlFlowGraph.getPreds(s2)).thenReturn(MockUtils.makeSet(s1));
    when(controlFlowGraph.getSuccs(s2)).thenReturn(MockUtils.makeSet(s3));
    when(controlFlowGraph.getPreds(s3)).thenReturn(MockUtils.makeSet(s2));
    when(controlFlowGraph.getSuccs(s3)).thenReturn(MockUtils.makeSet(s4,s5));
    when(controlFlowGraph.getPreds(s4)).thenReturn(MockUtils.makeSet(s3));
    when(controlFlowGraph.getSuccs(s4)).thenReturn(MockUtils.makeSet(s8));
    when(controlFlowGraph.getPreds(s5)).thenReturn(MockUtils.makeSet(s4));
    when(controlFlowGraph.getSuccs(s5)).thenReturn(MockUtils.makeSet(s4));
    when(controlFlowGraph.getSuccs(s8)).thenReturn(MockUtils.makeSet(b0));
    when(controlFlowGraph.getPreds(b0)).thenReturn(MockUtils.makeSet(s8));
    when(controlFlowGraph.getSuccs(b0)).thenReturn(MockUtils.makeSet());

    ReachingDefinitions reachingDefinitions = getReachingDefinitions(controlFlowGraph);
    Statement start = controlFlowGraph.getStart();
    Statement end = controlFlowGraph.getEnd();
    Set<Definition> definitions = reachingDefinitions.getReachingDefinitions(start);
    Set<Definition> definitions2 = reachingDefinitions.getReachingDefinitions(s2);
    Set<Definition> block = reachingDefinitions.getReachingDefinitions(b0);


    assertAll("Parameters Defined at Start",
        () -> assertTrue(doesDefine("a", definitions)),
        () -> assertTrue(doesDefine("b", definitions)),
        () -> assertEquals(start, s1),
        () -> assertEquals(end, b0),
        // because i still need to mock RDF builder
        () -> assertEquals(2, definitions.size()),
        () -> assertEquals(3, definitions2.size())
    );
  }
  private boolean doesDefine(String name, final Set<Definition> definitions) {
    for (Definition definition : definitions) {
      if (definition.name.getIdentifier().equals(name) && definition.statement == null) {
        return true;
      }
    }
    return false;
  }

  private ReachingDefinitions getReachingDefinitions(ControlFlowGraph controlFlowGraph) {
    List<ControlFlowGraph> list = new ArrayList<ControlFlowGraph>();
    list.add(controlFlowGraph);
    List<ReachingDefinitions> reachingDefinitionsList = unitUnderTest.build(list);
    assertEquals(1, reachingDefinitionsList.size());
    return reachingDefinitionsList.get(0);
  }

}
