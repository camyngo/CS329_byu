package cfgInputs;

public class Mocktest{
  void f(int a, int b) {
    int x;// s1
    x = 2; //s2
    if (x > 0) {
      while (x < 2) {
        x = x - 1 ; //s5
      }// s4
    } // s3
    else {
      x = 3 ; // s7
    }// s6
    return x; // s8
  }

}