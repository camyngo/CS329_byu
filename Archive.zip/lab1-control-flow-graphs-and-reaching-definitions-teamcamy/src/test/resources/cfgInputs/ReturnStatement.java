package cfgInputs;

public class ReturnStatement{
  void name() {
    int x = 2;
    return x;
  }
}