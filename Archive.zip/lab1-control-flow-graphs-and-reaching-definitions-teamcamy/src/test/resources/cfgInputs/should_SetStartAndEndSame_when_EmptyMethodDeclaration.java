package cfgInputs;

public class should_SetStartAndEndSame_when_EmptyMethodDeclaration {
  void name() {
  }  
}
