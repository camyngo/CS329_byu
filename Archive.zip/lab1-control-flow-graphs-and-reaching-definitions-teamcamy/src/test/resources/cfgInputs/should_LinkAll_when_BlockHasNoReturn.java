package cfgInputs;

public class should_LinkAll_when_BlockHasNoReturn {
  void name() {
    int i = 1;
    i = 2*i;
  }
}
