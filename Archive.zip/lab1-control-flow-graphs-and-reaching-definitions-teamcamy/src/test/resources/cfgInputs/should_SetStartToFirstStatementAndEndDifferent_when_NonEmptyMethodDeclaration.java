package cfgInputs;

public class should_SetStartToFirstStatementAndEndDifferent_when_NonEmptyMethodDeclaration {
  void name() {
    int i;
  }    
}
