package cfgInputs;

public class WhileStatement3{
  void name() {
    int i = 1;
    i = 2*i;
    return i;
  }
}
