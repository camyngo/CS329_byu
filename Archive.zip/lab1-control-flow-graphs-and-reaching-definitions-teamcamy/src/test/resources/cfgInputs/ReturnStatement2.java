package cfgInputs;

public class ReturnStatement2{
  void name() {
    int x = 3;
    return;
  }
}