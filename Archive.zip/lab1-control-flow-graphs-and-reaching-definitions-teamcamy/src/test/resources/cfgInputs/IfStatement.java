package cfgInputs;

public class IfStatement{

  void name() {
     int x = 0;
     if(x > 0){
       x = x + 2;
     }
     else {
       x = x -1;
     }
    return x;
  }
}