package cfgInputs;
public class Test {
  void name () {
    int a = 30;
    int b = 9 + (a + 5);
    int c;

    c = b + 4;
    if (10 < c) {
      c = c + 10;
    }
    return c + (60 + a);
  }
}