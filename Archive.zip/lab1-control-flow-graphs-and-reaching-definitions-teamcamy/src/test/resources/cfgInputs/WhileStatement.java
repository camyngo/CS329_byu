package cfgInputs;
public class WhileStatement{
  void name() {
    int x = 5;
    while(x>0) {
      x = x + 1;
    }
    return x;
  }
}