package cfgInputs;
public class WhileStatement2{
  void name() {
    while(x > 0) {

    }
    return x;
  }
}