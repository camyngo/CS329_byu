public class HasAllCaps {
    
    public void STUFF() {
//        
    }

}
