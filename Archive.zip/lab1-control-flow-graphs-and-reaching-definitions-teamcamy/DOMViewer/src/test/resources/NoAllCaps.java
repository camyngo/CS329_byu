package edu.byu.yc.tests;

import java.lang.String;
import java.lang.Object;

public class HasAllCaps {
    int x;
    public void stuff() {
        String y;
        int j;
        x = 7 - 8 - 9 / 3 / 1;
        while (x < 3){
                j = 4;
                continue;
        }
    }

    public Object foo(long l){
        return null;
    }
    public class Inner{
        HasAllCaps z = null;
    }
}