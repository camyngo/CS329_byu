# DOMViewer
A tool to create a tree view in HTML of the Eclipse JDT DOM representation of a Java file.

```
$ mvn install
...
$ mvn exec:java -D exec.args="MyProgram.java MyProgram.html"
```

