
package misc;

import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assumptions.assumeTrue;
import static org.junit.jupiter.api.Assumptions.assumingThat;

import java.sql.Array;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

public class FTests {


    @Test
    @Tag("Objects")
    @DisplayName("Requires objects are not null or empty")
    void ObjectsAreNotNullOrEmpty() {
        Object object = new Object();
        //empty array 
        Object[] arr = {};
        Object[] arr2 = {object};

        assertAll(
            () -> assertThrows(NullPointerException.class, () -> {
                Misc.ff(null, arr);
            }),

            () -> assertThrows(NullPointerException.class, () -> {
                Misc.ff(object, null);
            }),

            () -> assertNotNull(arr2),
            () -> assertNotNull(object)
        );

    }

    
    @Tag("Adding object to the array")
    @Nested
    class Testing {
        @Test
        @DisplayName("Requires object will not exist in the array")
        void ObjectNotExistInArray(){
            Object object = new Object();
            Object[] arr = {1, 2 ,3 ,4};
            assertAll(
                () -> assertNotNull(arr),
                () -> assertNotNull(object),
                () -> {
                    for (int i = 0; i < arr.length; i++) { 
                        if (arr[i].equals(object)) {
                        throw new NullPointerException();
                        } 
                      } 
                }
            );
        }

      @Test
      @DisplayName("Object exists in the array")
      void ObjectExistInArray(){
        Object object = 4;
        Object[] arr = {1, 2 ,3 ,4, 7};
        assertAll(
            () -> assertNotNull(arr),
            () -> assertNotNull(object),
            () -> {
              for (int i = 0; i < arr.length; i++) {
                if (arr[i].equals(object)) {
                  System.out.print("Number is in the system");
                  continue;
                }
              }
            }
        );
      }

        @Test
        @DisplayName("Requires array to have an empty index and object will not exist in the array")
        void AddingToTheArray(){
            // checking again to make sure the object are not in the array
            Object object = 5;
            Object[] arr = { 1, 2, 3, 4, ""};
            assertAll(
                () -> assertNotNull(arr),
                () -> assertNotNull(object),
                () -> {
                    for (int i = 0; i < arr.length; i++) { 
                        if (object.equals(arr[i])) {
                        throw new NullPointerException();
                        } 
                      } 
                }
            );
            // loop
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] == null) {
                    // add the object into array
                    arr[i] = object;
                }
                // if no exist empty space
                else {
                    // make a new object of arr2
                    Object [] arr2 = new Object[arr.length + 1];
                    //ensure the size is up by 1
                    assertEquals(arr2.length, arr.length + 1);
                }
            }

            // if exist do not throw
            assertDoesNotThrow(() -> {
                    for (int i = 0; i < arr.length; i++) { 
                        if (arr[i].equals(object));
                    }
                }
            );
        }

    }

}
