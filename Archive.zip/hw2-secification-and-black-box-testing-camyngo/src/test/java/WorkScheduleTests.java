import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WorkScheduleTests {
  static WorkSchedule ws = null;

  @AfterEach
  public void done() {
    ws = null;
  }

  @Test
  @DisplayName("Test Edges Cases for the Constructor")
  public void testWorkScheduleSize() {
    assertAll(
      () -> {
        // check negative working hours
        assertThrows(Exception.class, () -> new WorkSchedule(-1));
      },
      () -> {
        // check 0 employee was assigned
        assertDoesNotThrow(()-> new WorkSchedule(0));
      }
    );
  }

  @Test
  @DisplayName("Test Add Working Period")
  public void TestAddWorkingPeriod() {
    // 20 hours created, and need 10 people from 1 to 10, added 4 employees
    ws = new WorkSchedule(20);
    ws.setRequiredNumber(2, 1, 10);
    assertTrue(ws.addWorkingPeriod("Employee A", 2, 5));
    assertTrue(ws.addWorkingPeriod("Employee B", 1, 8));;

    // following add should be false since only 2 employees needed
    assertFalse(ws.addWorkingPeriod("Employee C", 3, 4));
    assertFalse(ws.addWorkingPeriod("Employee D", 5, 9));
  }

  @Test
  @DisplayName("Test Working Employees")
  public void testWorkingEmployees() {
    ws = new WorkSchedule(10);
    ws.setRequiredNumber(6, 1, 9);
    ws.addWorkingPeriod("Employee A", 2, 5);
    ws.addWorkingPeriod("Employee B", 1, 8);;

    // since A and B were successfully added, during 2-5, B is the only one working
    String[] expectedEmployee = {"Employee B", "Employee A"};
    assertNotEquals(expectedEmployee, ws.workingEmployees(1,5));
  }

  @Test
  @DisplayName("Test Read Schedule")
  public void testReadSchedule () {
    ws = new WorkSchedule(8);

    assertAll(
            () -> {
              // check negative working hours
              assertThrows(Exception.class, () -> ws.readSchedule(-1));
            },
            () -> {
              // check a time that's in range
              assertDoesNotThrow(()-> ws.readSchedule(3));
              assertNotNull(ws.readSchedule(3));
            },
            () -> {
              // overwrite the size passed into the constructor
              assertThrows(Exception.class, () -> ws.readSchedule(10));
            }
    );
  }

  @Test
  @DisplayName("Test Next Incomplete")
  public void testNextIncomplete() {
    ws = new WorkSchedule(20);
    ws.setRequiredNumber(10, 0, 10);

    // since the time-interval is not assigned to any employees
    // the next incomplete time slot would be 0
    int expected = 0;
    assertEquals(expected, ws.nextIncomplete(0));
  }

  @Test
  @DisplayName("Test Set Required Time")
  public void testSetRequiredTime() {
    ws = new WorkSchedule(20);

    assertAll(
            () -> {
              // set endtime to 21 to get out-of-range exception
              assertThrows(Exception.class, () -> ws.setRequiredNumber(30, 0, 21));
            },
            () -> {
              // should be correct since 1 is within the range of Hours array
              assertDoesNotThrow(() -> ws.setRequiredNumber(30, 0, 1));
            }
    );
  }
}

//  /**
//   * creates a schedule which contains the hours 0,1,2,( ...,size - 1 where for
//   * each hour the number of needed employees is set to zero and there are no
//   * employees assigned to it

//   * @requires: size > 0

//   * @ensures: Hours.size() = size
//   * @ensures: Hours != null

//   * @param size the size of the Hours array
//   */
//  public WorkSchedule(int size) {}
//
//  /**
//   * gives back an object of the class Hour, which has two fields: requiredNumber
//   * of type int is the required number of employees working at hour time.
//   * workingEmployees of type String[] is the names of the employees who have so
//   * far been assigned to work at hour time.

//   * @require: time > 0
//   * @require: time <= Hours.size()-1

//   * @param time the time block contains employees assigned to it
//   * @return (out: Hour) a Hour object contains required number of employees working
//   * at that hour and a list of name of the employees assigned at that time.
//   */
//  public Hour readSchedule(int time) {}
//
//  /**
//   * sets the number of required working employees to nemployee for all hours in
//   * the interval starttime to endtime.

//   * @param nemployee numbers of employees assigned
//   * @param starttime the start time of the interval
//   * @param endtime the end time of the interval

//   * @requires: starttime > 0
//   * @requires: endtime > 0
//   * @requires: starttime < endtime
//   * @requires: endtime <= Hours.size()-1

//   * @ensures: for starttime <= i <= endtime, Hours[i] != null
//   */
//  public void setRequiredNumber(int nemployee, int starttime, int endtime) {}
//
//  /**
//   * schedules employee to work during the hours from starttime to endtime.

//   * @param employee, the name of the employee
//   * @param starttime, the start time of the interval
//   * @param endtime, the end time of the interval

//   * @requires: starttime > 0
//   * @requires: endtime > 0
//   * @requires: starttime < endtime
//   * @requires: endtime <= Hours.size() - 1

//   * @ensures for starttime <= i <= endtime, Hours[i] == employee
//   */
//  public boolean addWorkingPeriod(String employee, int starttime, int endtime) {}
//
//  /**
//   * returns a list of all employees working at some point during the interval
//   * starttime to endtime.
//   * @param starttime, the start time of the interval
//   * @param endtime, the end time of the interval

//   * @requires: starttime > 0
//   * @requires: endtime > 0
//   * @requires: starttime < endtime

//   * @ensures: forall i in Hours, Hours[i] != null
//   */
//  public String[] workingEmployees(int starttime, int endtime) {}
//
//  /**
//   * returns the closest time starting from currenttime for which the required
//   * amount of employees has not yet been scheduled.
//   * @param currenttime, the current time

//   * @requires: currenttime > 0
//   * @requires: currenttime < Hours.size() - 1

//   * @return an integer represents the next time that has not finished
//   * employee assignment at the time
//   */
//  public int nextIncomplete(int currenttime) {}