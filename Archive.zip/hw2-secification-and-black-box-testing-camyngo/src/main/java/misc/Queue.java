
package misc;
public class Queue {
  Object[] arr;
  int size;
  int first;
  int last;

  /**
   * Creates a queue with a bounded size.
   * @requires max = 100
   * @requires size(Q) < max
   * 
   * @ensures size = 0 && first = 0 && last = 0;
   * @ensures Q.fresh()
   * @ensures Q[first] == null
   * @ensures Q.max() = max
   * @param max   the size of the queue
   */
  public Queue(int max) {
    arr = new Object[max];
    size = 0;
    first = 0;
    last = 0;
  }

  /**
   * Returns the size of this set (e.g., its rank).
   * @requires size >= 0
   *
   * @ensure size(Q) = 0, Q is empty
   * @return (size : int) the number of unique elements in the set
   */
  public int size() {
    return size;
  }

  /**
   * Returns the max size of this set (e.g., its rank).
   * @requires max > 0
   * 
   * @return (max : int) return the max capacity of the queue
   */
  public int max() {
    return arr.length;
  }

  /**
   * Adds a new object into the queue.
   * @requires Q != null && x!= null
   * @requires size(Q) < max(Q)
   * 
   * @ensures Q[size(old(Q))] = x
   * @ensures size(old(Q)) + 1 = size(Q)
   * @ensures Q[last] = x 
   * @ensures old(Q) = Q - x
   * @ensures for all i, 0 <= i < size(old(Q)), Q[i] = old(Q)[i]
   * @param x the object to add to the queue
   */
  public void enqueue(Object x) {
    arr[last] = x;
    last++;
    if (last == arr.length) {
      last = 0;
    }
    size++;
  }

  /**
   * Removes an object from the queue.
   * @requires Q != null
   * @requires size(Q) < max(Q)
   * @requires size >= 0
   * 
   * @ensures for all i, 0 <= i < size(old(Q)), Q[i] = old(Q)[i]
   * @ensures size(old(Q)) - 1 = size(Q)
   * @ensures old(Q) = Q - Q[last]
   * @ensure size(Q) = 0, Object is null
   * @return the removed object
   */
  public Object dequeue() {
    if (size == 0) {
      return null;
    }
    final Object x = arr[first];
    first++;
    if (first == arr.length) {
      first = 0;
    }
    size--;
    return x;
  }
}
