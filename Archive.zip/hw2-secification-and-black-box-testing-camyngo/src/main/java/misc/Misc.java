package misc;

public class Misc {

  /**
   * Adds an element to an array if it is not already in the array.
   * @requires arr!= null
   *
   * check before add to the array
   * @ensures for all i, 0 <= i < arr.length; arr[i] != x then arr[i] = old(array[i])
   *
   * after adding x to the array
   * @ensures for all i, 0 <= i < old(size(arr)) ; arr[i] = old(array[i])
   * @ensures if x is not in arr, then arr[last] = x and size(array) = size(old(array)) + 1
   * 
   * @param x element to add
   * @param arr array to which x is added
   */
  public static void ff(Object x, Object[] arr) {
    boolean exists = false;
    if(x == null || arr == null) throw new NullPointerException();

    for (int i = 0; i < arr.length; i++) { // A1
      if (x.equals(arr[i])) { // B1
        exists = true;
        break;
      } // B2
    } // A2
    if (!exists) { //C1
      for (int i = 0; i < arr.length; i++) { // D1
        if (arr[i] == null) { // E1
          arr[i] = x;
          break;
        } // E2
      } // D2
    } // C2
  }
}
